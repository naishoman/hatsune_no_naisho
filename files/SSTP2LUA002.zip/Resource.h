//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SSTP2LUA.rc
//

#define IDD_ABOUTBOX			100
#define IDI_SSTP2LUA			101
#define IDI_SMALL				102
#define IDC_MENU1				103

// �V�����I�u�W�F�N�g�̎��̊���l
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NO_MFC					130
#define _APS_NEXT_RESOURCE_VALUE	129
#define _APS_NEXT_COMMAND_VALUE		32771
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		110
#endif
#endif
