// SSTP2LUA.cpp : �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"
#include "SSTP2LUA.h"

#include <stdio.h>
#include <shellapi.h>
#include <shlobj.h>

#define MAPPING_SIZE	0x10000
#define MAX_LYRIC_SIZE	255			//�蔲��

char szPrevLyric[MAX_LYRIC_SIZE];

INT_PTR CALLBACK	MyDlgProc(HWND, UINT, WPARAM, LPARAM);
BOOL RegisterSSTPHost(HWND hWnd);
BOOL UnRegisterSSTPHost(HWND hWnd);
void Send_Lua_Script(int surface1,int surface2,int wait,const char* szLyric,int len);
void DropFiles(HWND hWnd,TCHAR* pszFilename,int x,int y);

#define LUA_SCRIPT1									\
	"Miku_LipSyncData = {\r\n"						\
	"	[\"Offset\"] = 0.000000,\r\n"				\
	"	[\"Count\"] = 2,\r\n"						\
	"	[\"Channel\"] = 2,\r\n"						\
	"	[\"PlayIndex\"] = 1,\r\n"					\
	"	[\"BGM\"] = \"dummy.mp3\",\r\n"				\
	"	[\"Load\"] = true,\r\n"						\
	"	[\"Data\"] = {\r\n"							\
	"		[1] = {\r\n"							\
	"			[\"Speed\"] = 4,\r\n"				\
	"			[\"Time1\"] = 0.00000,\r\n"			\
	"			[\"Anime\"] = \"%s\",\r\n"			\
	"			[\"Word\"] = \"��\",\r\n"			\
	"		},\r\n"									\
	"		[2] = {\r\n"							\
	"			[\"Speed\"] = 1,\r\n"				\
	"			[\"Time1\"] = 4.00000,\r\n"			\
	"			[\"Anime\"] = \"LipClose\",\r\n"	\
	"			[\"Word\"] = \"\",\r\n"				\
	"		},\r\n"									\
	"	},\r\n"										\
	"}\r\n"

#define LUA_SCRIPT2									\
	"Miku_LipSyncData = {\r\n"						\
	"	[\"Offset\"] = 0.000000,\r\n"				\
	"	[\"Count\"] = 3,\r\n"						\
	"	[\"Channel\"] = 2,\r\n"						\
	"	[\"PlayIndex\"] = 1,\r\n"					\
	"	[\"BGM\"] = \"dummy.mp3\",\r\n"				\
	"	[\"Load\"] = true,\r\n"						\
	"	[\"Data\"] = {\r\n"							\
	"		[1] = {\r\n"							\
	"			[\"Speed\"] = 4,\r\n"				\
	"			[\"Time1\"] = 0.00000,\r\n"			\
	"			[\"Anime\"] = \"%s\",\r\n"			\
	"			[\"Word\"] = \"��\",\r\n"			\
	"		},\r\n"									\
	"		[2] = {\r\n"							\
	"			[\"Speed\"] = 4,\r\n"				\
	"			[\"Time1\"] = %f,\r\n"				\
	"			[\"Anime\"] = \"%s\",\r\n"			\
	"			[\"Word\"] = \"��\",\r\n"			\
	"		},\r\n"									\
	"		[3] = {\r\n"							\
	"			[\"Speed\"] = 1,\r\n"				\
	"			[\"Time1\"] = 4.00000,\r\n"			\
	"			[\"Anime\"] = \"LipClose\",\r\n"	\
	"			[\"Word\"] = \"\",\r\n"				\
	"		},\r\n"									\
	"	},\r\n"										\
	"}\r\n"

#define SCRIPT_TEXT1						\
	L"<force_include \"temp.lua\">\n"		\
	L"<text_style \"Center\",\"Shadow\">\n"	\
	L"<cm>\n"								\
	L"<delay 0>\n"

#define SCRIPT_TEXT2						\
	L"<force_include \"temp.lua\">\n"		\
	L"<delay 0>\n"

//
TCHAR tszTempTxt[MAX_PATH];
TCHAR tszTempLua[MAX_PATH];
HANDLE hMapping = NULL;
HWND hTarget = NULL;

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	// �e���|�����t�@�C�����𐶐�
	GetModuleFileName(NULL,tszTempLua,MAX_PATH);
	_tcscpy(_tcsrchr(tszTempLua,TEXT('\\'))+1,TEXT("temp.lua"));
	GetModuleFileName(NULL,tszTempTxt,MAX_PATH);
	_tcscpy(_tcsrchr(tszTempTxt,TEXT('\\'))+1,TEXT("temp.txt"));

	// �̎��o�b�t�@���N���A
	szPrevLyric[0] = '\0';

	DialogBox(hInstance, MAKEINTRESOURCE(IDD_ABOUTBOX), NULL, MyDlgProc);

	return 0;
}

HWND FindTargetWindow()
{
	// Skyline Scripter��T���B
	return FindWindow(TEXT("SWIN_WndBase"),TEXT("Skyline Scripter"));
}

char* Create_FSO_String(HWND hWnd)
{
	char szPath[MAX_PATH+1];
	char buf[512];
	GetCurrentDirectoryA(MAX_PATH,szPath);
	sprintf(buf,"sstp2lua_fmo_header.hwnd\001%d\r\n"\
				"sstp2lua_fmo_header.name\001%s\r\n"\
				"sstp2lua_fmo_header.keroname\001none\r\n"\
				"sstp2lua_fmo_header.path\001%s\r\n"\
				"sstp2lua_fmo_header.kerohwnd\001%d\r\n"\
				"sstp2lua_fmo_header.ghostpath\001%s\r\n",
				(int)hWnd,"SSTP2LUA",szPath,(int)hWnd,szPath);
	return strdup(buf);
}

const char* Surface2Lip(int surface)
{
	// FLELE Miku�ݒ� (SSTP.ini�ƍ��킹��)
	switch ( surface )
	{
		case 1003:	//[a]
		case 1002:	//[aa]
			return "Lip4";
			break;
		case 1006:	//[i]
			return "Lip2";
			break;
		case 1004:	//[u]
			return "LipO";
			break;
		case 1008:	//[e]
			return "Lip1";
			break;
		case 1009:	//[o]
		case 1005:	//[xo]
			return "LipO3";
			break;
		case 1000:	//[xo]
			return "LipO";
			break;
		default:
			break;
	}
	return "LipClose";
}

void Create_Lua_Script(const char* sakura)
{
	// �Ώۂ��L�����`�F�b�N
	if ( IsWindow(hTarget) )
		hTarget = NULL;

	// �Ώۂ������Ȃ�T��
	if ( !hTarget )
		hTarget = FindTargetWindow();

	if ( !hTarget )
		return;		// �Ώۂ��Ȃ��̂ŏI��

	const char* ptr = strstr(sakura,"Script: ");
	if ( !ptr )
		return;

	ptr += 8;
	if ( !memcmp(ptr,"\\_q",3) )
		ptr+=3;

	int surface1;
	int surface2 = -1;
	int wait = 0;
	const char* ptr2;
	ptr2 = strstr(ptr,"\\s[");
	if ( ptr2 )
	{
		int len = ptr2 - ptr;
		surface1 = atoi(ptr2+3);
		
		// Wait
		ptr2 = strstr(ptr2,"\\_w[");
		if ( ptr2 )
		{
			wait = atoi(ptr2+4);

			// Send 1st/2nd Lip
			ptr2 = strstr(ptr2,"\\s[");
			if ( ptr2 )
				surface2 = atoi(ptr2+3);
		}
		Send_Lua_Script(surface1,surface2,wait,ptr,len);
	}

}

void Send_Lua_Script1(const char* szLip,const char* szLyric,int len)
{
	char buf[512];
	HANDLE hFile = CreateFile(tszTempLua,GENERIC_READ|GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	if ( hFile == INVALID_HANDLE_VALUE )
		return;
	DWORD dwWritten = 0;
	WriteFile(hFile,buf,(DWORD)strlen(buf),&dwWritten,NULL);
	CloseHandle(hFile);
	DropFiles(hTarget,tszTempLua,0,0);
}

void Send_Lua_Script(int surface1,int surface2,int wait,const char* szLyric,int len)
{
	char buf[512+2*MAX_LYRIC_SIZE];	// �K��
	if ( surface2 == -1 )
	{
		sprintf(buf,LUA_SCRIPT1,
				Surface2Lip(surface1)
				);
	}
	else
	{
		sprintf(buf,LUA_SCRIPT2,
				Surface2Lip(surface1),
				(double)wait/1000.0,
				Surface2Lip(surface2)
				);
}

	HANDLE hFile = CreateFile(tszTempLua,GENERIC_READ|GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	if ( hFile == INVALID_HANDLE_VALUE )
		return;
	DWORD dwWritten = 0;
	WriteFile(hFile,buf,(DWORD)strlen(buf),&dwWritten,NULL);
	CloseHandle(hFile);

	if ( len < MAX_LYRIC_SIZE )
	{
		int prev_len = strlen(szPrevLyric);
		int script_size = sizeof(SCRIPT_TEXT1)/2;
		WCHAR* szScript = SCRIPT_TEXT1;
		const char* ptr = szLyric;
		int len2 = len;
		if ( !memcmp(szPrevLyric,szLyric,prev_len) && len )
		{
			strcpy(szPrevLyric,szLyric);
			len2 -= prev_len;
			ptr += prev_len;
			script_size = sizeof(SCRIPT_TEXT2)/2;
			szScript = SCRIPT_TEXT2;
		}
		strcpy(szPrevLyric,szLyric);
		szPrevLyric[len] = '\0';

		WCHAR* wbuf = (WCHAR*)buf;
		wsprintf(wbuf,szScript);
		int c = MultiByteToWideChar(CP_ACP, 0, ptr, len2, wbuf+script_size-1, MAX_LYRIC_SIZE );
		wbuf[c+script_size-1] = L'\n';
		wbuf[c+script_size] = L'\0';

		HANDLE hFile = CreateFile(tszTempTxt,GENERIC_READ|GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
		if ( hFile == INVALID_HANDLE_VALUE )
			return;
		DWORD dwWritten = 0;
		char szBOM[] = "\xff\xfe";
		WriteFile(hFile,szBOM,2,&dwWritten,NULL);
		WriteFile(hFile,buf,(DWORD)wcslen(wbuf)*2,&dwWritten,NULL);
		CloseHandle(hFile);
		DropFiles(hTarget,tszTempTxt,0,0);
		return;
	}

	DropFiles(hTarget,tszTempLua,0,0);
}

BOOL RegisterSSTPHost(HWND hWnd)
{
	BOOL fExist = FALSE;
	hMapping = CreateFileMapping(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,MAPPING_SIZE,TEXT("Sakura"));
	if ( !hMapping )
		return FALSE;

	if ( GetLastError() == ERROR_ALREADY_EXISTS )
		fExist = TRUE;

	// �r�����Ȃ��Ă����́H�H�H�H
	char* lpMapAdr = (LPSTR)MapViewOfFile(hMapping,FILE_MAP_ALL_ACCESS, 0, 0, 0);
	char* szMyInfo = Create_FSO_String(hWnd);
	int info_size = strlen(szMyInfo);
	if ( !fExist )
	{
		*(DWORD*)lpMapAdr = MAPPING_SIZE;
		memcpy(lpMapAdr+4,szMyInfo,info_size);
		*(lpMapAdr+4+info_size) = 0;
	}
	else
	{
		int size = *(DWORD*)lpMapAdr;
		memmove(lpMapAdr+4+info_size,lpMapAdr+4,size-info_size-4);
		memcpy(lpMapAdr+4,szMyInfo,info_size);
	}
	UnmapViewOfFile(lpMapAdr);

	free(szMyInfo);

	return TRUE;
}

BOOL UnRegisterSSTPHost(HWND hWnd)
{
	if ( !hMapping )
		return FALSE;

	// �r�����Ȃ��Ă����́H�H�H�H
	char* lpMapAdr = (LPSTR)MapViewOfFile(hMapping,FILE_MAP_ALL_ACCESS, 0, 0, 0);
	char* szMyInfo = Create_FSO_String(hWnd);
	int info_size = strlen(szMyInfo);
	char *ptr = strstr(lpMapAdr+4,szMyInfo);
	free(szMyInfo);
	if ( ptr )
	{
		int size = *(DWORD*)lpMapAdr;
		memmove(ptr,ptr+info_size,size-(ptr+info_size-lpMapAdr));
	}

	UnmapViewOfFile(lpMapAdr);
	CloseHandle(hMapping);

	if ( !ptr )
		return FALSE;	//���͒N�H�H�H

	return TRUE;
}

void DropFiles(HWND hWnd,TCHAR* pszFilename,int x,int y)
{
	int work_size = 0;			//DROPFILES�\���̂̃f�[�^�T�C�Y + ������

	work_size = work_size + _tcslen(pszFilename)+1;
	work_size++;
	work_size *= sizeof(TCHAR);
	work_size += sizeof(DROPFILES);
	work_size += 1024;	//????

	HANDLE hMem = GlobalAlloc(GMEM_ZEROINIT,work_size);
	DROPFILES* pDropFiles = (DROPFILES*)GlobalLock(hMem);

	pDropFiles->pFiles = sizeof(DROPFILES);
	pDropFiles->pt.x = x;
	pDropFiles->pt.y = y;
	pDropFiles->fNC = FALSE;
#ifdef UNICODE
	pDropFiles->fWide = TRUE;
#else
	pDropFiles->fWide = FALSE;
#endif

	TCHAR *pFileName = (TCHAR*)((char *)pDropFiles + sizeof(DROPFILES));
	int cFileName;
	cFileName = _tcslen(pszFilename);
	memcpy(pFileName,pszFilename,cFileName*sizeof(TCHAR));
	pFileName[cFileName] = TEXT('\0');
	pFileName += cFileName;
	pFileName[cFileName] = '\0';

	PostMessage(hWnd,WM_DROPFILES,(WPARAM)hMem,0);	//�h���b�v���b�Z�[�W���w�肳�ꂽ�E�B���h�E�ɑ��M

	GlobalUnlock(hMem);
}

BOOL ResisterIcon(HWND hWnd)
{
	// �ʒm�̈�̃A�C�R�����쐬
	NOTIFYICONDATA nid;

	nid.cbSize = sizeof(NOTIFYICONDATA);
	nid.hWnd = hWnd;
	nid.uID = 0;
	nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
	nid.uCallbackMessage = WM_USER;
	nid.hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_SMALL));
	_tcscpy(nid.szTip, TEXT("SSTP2Lua"));

	return Shell_NotifyIcon(NIM_ADD, &nid);
}

BOOL UnregisterIcon(HWND hWnd)
{
	NOTIFYICONDATA nid;
    nid.cbSize = sizeof(nid);
    nid.hWnd = hWnd;
    nid.uID = 0;
    return Shell_NotifyIcon(NIM_DELETE, &nid);
}

INT_PTR CALLBACK MyDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	HMENU hPopMenu;
	POINT  pt;

	switch (message)
	{
	case WM_INITDIALOG:
		ResisterIcon(hDlg);
		RegisterSSTPHost(hDlg);
		return (INT_PTR)TRUE;

	case WM_NCPAINT:	// �蔲����\��
		ShowWindow(hDlg,SW_HIDE);
		break;

	case WM_DESTROY:
		UnregisterIcon(hDlg);
		UnRegisterSSTPHost(hDlg);
		return (INT_PTR)TRUE;

      case WM_USER:
		switch ( lParam )
		{
			case WM_RBUTTONDOWN:
				hPopMenu = LoadMenu(NULL,MAKEINTRESOURCE(IDC_MENU1));
				GetCursorPos(&pt);
				SetForegroundWindow(hDlg);
				SetFocus(hDlg);
				TrackPopupMenu(GetSubMenu(hPopMenu,0),TPM_LEFTALIGN|TPM_RIGHTBUTTON,pt.x,pt.y,0,hDlg,NULL);
				PostMessage(hDlg,WM_NULL,0,0);
				DestroyMenu(hPopMenu);
				return 0;
		}
		return 0;

	case WM_COPYDATA:
		{
			COPYDATASTRUCT* pcds = (COPYDATASTRUCT*)lParam;
			if ( pcds->dwData == 9801 )
				Create_Lua_Script((char*)pcds->lpData);
		}
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		switch ( LOWORD(wParam) )
		{
			case IDOK:
			case IDCANCEL:
				EndDialog(hDlg, LOWORD(wParam));
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
