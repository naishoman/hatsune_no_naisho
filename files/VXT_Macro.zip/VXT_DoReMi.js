var arTexts = new Array("��","��","��","��","��","�ӂ�","�ӂ�","��","��","��","��","��");
var arSymbols = new Array("d o","d o","4 e","4 e","m' i","p\ a","p\ a","s o","s o","4 a","4 a","S i");

if ( GetSelectedString(0) == "" )
	Editor.SelectAll()

var beginLine = Editor.GetSelectLineFrom();
var endLine = Editor.GetSelectLineTo();

var arNotes = [];
for ( lineNum = beginLine ; lineNum < endLine ; lineNum++ )
{
	var lineData = Editor.GetLineStr(lineNum);
	if ( lineData.indexOf("Note#=") == 0 )
	{
		var value = parseInt(lineData.substr(6));
		var handle = "";
		while ( lineNum++ )
		{
			lineData = Editor.GetLineStr(lineNum);
			if ( lineData.indexOf("LyricHandle=") == 0 )
			{
				arNotes["["+lineData.substr(12,6)+"]"] = value;
				break;
			}
		}
	}
}

for ( var handle in arNotes )
{
	Editor.SearchClearMark();
	Editor.SearchNext(handle, 40);
	var lineData = Editor.GetLineStr(parseInt(ExpandParameter("$y"))+1).split(",");
	Editor.Down_Sel();
	Editor.GoLineEnd_Sel();
	Editor.Right_Sel();
	var tone = arNotes[handle] % 12;
	lineData[0] = handle+"\nL0=\""+arTexts[tone]+"\"";
	lineData[1] = "\""+arSymbols[tone]+"\"";
	Editor.InsText(lineData.join());
}
