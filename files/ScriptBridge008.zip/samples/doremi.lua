-- doremi.jsのproxyスクリプトです。
require("ScriptBridge")

-- プラグインマニフェスト関数.
function manifest()
    myManifest = {
        name          = "ドレミJobプラグイン版",
        comment       = "歌詞を音階に変更します。",
        author        = "ないしょの人",
        pluginID      = "{427577BB-25C4-4085-A44A-AA173F1F76EB}",
        pluginVersion = "1.0.0.2",
        apiVersion    = "3.0.0.1"
    }
    
    return myManifest
end
