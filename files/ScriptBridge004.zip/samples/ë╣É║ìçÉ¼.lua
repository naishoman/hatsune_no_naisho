-- 音声合成.js のproxyスクリプト
require("ScriptBridge")
