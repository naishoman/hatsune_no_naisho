var VoiceObj = new ActiveXObject("Sapi.SpVoice");
var VoicesToken = VoiceObj.GetVoices();
for( var i=0; i< VoicesToken.Count ; i++ )
{
	var name = VoicesToken.Item(i).GetDescription();
	if ( name == "Vocaloid" )
		VoiceObj.Voice = VoicesToken.Item(i);
}
VoiceObj.Speak("�݂����݂����ɂ��Ă���B");

