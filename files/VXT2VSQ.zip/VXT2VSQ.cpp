// VXT2VSQ.cpp : �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"
#include "VXT2VSQ.h"

#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>

// �O���[�o���ϐ�:
extern char txt_file[MAX_PATH+1];
extern char szEditor[MAX_PATH+1];

#define	IDOL_WAIT		(500)

typedef struct _MIDI_MASTER_EVENTS
{
	DWORD dwTick;
	DWORD dwData;
} MIDI_MASTER_EVENTS;

BOOL MakeTempFileName(char* szTempFile,char* szTempExt)
{
	char vocaloid_path[MAX_PATH];
	GetModuleFileName(NULL,vocaloid_path,MAX_PATH);
	char *path_token = strrchr(vocaloid_path,'\\');
	if ( !path_token )
		return FALSE;

	*path_token = '\0';

	LARGE_INTEGER liStart = {0, 0};
	char tmp_name[MAX_PATH];
	do
	{
		QueryPerformanceCounter( &liStart );

		sprintf(tmp_name,"\\audiotemp\\VM%08x.%s",liStart.LowPart,szTempExt);
		strcpy(szTempFile,vocaloid_path);
		strcat(szTempFile,tmp_name);
		Sleep(1);
	} while ( GetFileAttributes(szTempFile) != -1 );

	return TRUE;
}

BOOL WriteTrackText(HANDLE hTXT,char* szTrackName,HANDLE hVSQ)
{
	DWORD red = 0;
	DWORD written = 0;
	char buf[128];

	DWORD dwSize = GetFileSize(hTXT,NULL);

	char token[] = "MTrk\0\0\0\0\0\xff\3\0";
	token[11] = strlen(szTrackName);
	DWORD dwTrkSize;
	int line = (dwSize+0x76)/0x77;
	if ( line <= 10000 )
		dwTrkSize = line*12 + 8 + token[11] + dwSize;
	else
		dwTrkSize = 10000*12 + ((dwSize-0x77*10000+0x72)/0x73)*16 + 8 + token[11] + dwSize;
	token[4] = dwTrkSize >> 24;
	token[5] = dwTrkSize >> 16;
	token[6] = dwTrkSize >> 8;
	token[7] = dwTrkSize;
	WriteFile(hVSQ,token,12,&written,NULL);
	if ( written != 12 )
		return FALSE;
	WriteFile(hVSQ,szTrackName,token[11],&written,NULL);
	if ( written != token[11] )
		return FALSE;

	int k = 0;
	while ( dwSize )
	{
		DWORD dwReadSize;
		int n;
		if ( k < 10000 )
		{
			n = 8;
			dwReadSize = dwSize > 0x77 ? 0x77 : dwSize;
		}
		else
		{
			n = 12;
			dwReadSize = dwSize > 0x73 ? 0x73 : dwSize;
		}
		ReadFile(hTXT,buf,dwReadSize,&red,NULL);
		if ( dwReadSize != red )
			return FALSE;

		char token[16];
		token[0] = 0;
		token[1] = 0xff;
		token[2] = 0x1;
		token[3] = dwReadSize+n;
		WriteFile(hVSQ,token,4,&written,NULL);
		if ( written != 4 )
			return FALSE;
		if ( k < 10000 )
		{
			sprintf(token,"DM:%04d:",k++);
			WriteFile(hVSQ,token,8,&written,NULL);
			if ( written != 8 )
				return FALSE;
		}
		else
		{
			sprintf(token,"DM:%08d:",k++);
			WriteFile(hVSQ,token,12,&written,NULL);
			if ( written != 12 )
				return FALSE;
		}
		WriteFile(hVSQ,buf,dwReadSize,&written,NULL);
		if ( written != dwReadSize )
			return FALSE;

		buf[dwReadSize] = '\0';
		dwSize -= red;
	}

	token[0] = 0x0;
	token[1] = 0xff;
	token[2] = 0x2f;
	token[3] = 0x00;
	WriteFile(hVSQ,token,4,&written,NULL);
	if ( written != 4 )
		return FALSE;

	return TRUE;
}

int SectionLineCounts(char *ptr)
{
	char *szToken = strchr(ptr,'[');
	if ( !ptr )
		szToken = ptr + strlen(ptr);

	int counts = 0;
	for ( ; ptr <= szToken ; ptr++ )
	{
		if ( *ptr == '\n' )
			counts++;
	}
	return counts;
}

int VXT2VSQInternal(char* szVXTText,DWORD dwSize,HANDLE hVSQ,BOOL fTemp)
{
	int tracks = 1;
	int timeFormat = 480;
	int tempo = 50000;
	int Beats = 4;
	int Quarter=2;
	int Ticks=24;

	int nEvents = 0;
	int nAllocEvents = 0;
	MIDI_MASTER_EVENTS* pEvents = NULL;

	char* ptr = szVXTText;
	while ( dwSize )
	{
		if ( !strnicmp(ptr,"[Master]\n",9) )
		{
			dwSize -= 9;
			ptr += 9;
			while ( dwSize )
			{
				if ( *ptr == '[' )
					break;

				char* szToken = ptr;
				if ( !strnicmp(ptr,"TimeFormat=",11) )
				{
					ptr += 11;
					timeFormat = atoi(ptr);
				}
				else
				{
					if ( pEvents )
						free(pEvents);
					return 0;
				}
				ptr = strchr(ptr,'\n');
				if ( !ptr )
				{
					if ( pEvents )
						free(pEvents);
					return 0;
				}
				ptr++;
				dwSize -= ptr - szToken;
			}

			DWORD written;
			char token[] = "MThd\0\0\0\6\0\1\0\0\0\0";
			token[12] = timeFormat >> 8;
			token[13] = timeFormat;
			WriteFile(hVSQ,token,sizeof(token)-1,&written,NULL);
			if ( written != sizeof(token)-1 )
			{
				if ( pEvents )
					free(pEvents);
				return FALSE;
			}

	// 00 FF 03 0C 4D 61 73 74 65 72 20 54 72 61 63 6B  �g���b�N�� "MasterTrack"
	// 00 FF 51 03 14 85 F7								�e���|
	// 00 FF 58 04 04 02 18 08							���q�ݒ�
	// 00 FF 2F 00										EOT

		}
		else if ( !strnicmp(ptr,"[Tempo]\n",8) )
		{
			dwSize -= 8;
			ptr += 8;
			nAllocEvents = nEvents + SectionLineCounts(ptr);
			if ( pEvents )
				pEvents = (MIDI_MASTER_EVENTS*)realloc(pEvents,sizeof(MIDI_MASTER_EVENTS)*nAllocEvents);
			else
				pEvents = (MIDI_MASTER_EVENTS*)malloc(sizeof(MIDI_MASTER_EVENTS)*nAllocEvents);

			while ( dwSize )
			{
				if ( *ptr == '[' )
					break;

				DWORD dwTick = atoi(ptr);
				char* szToken = ptr;
#if	1
				int i = 0;
				for ( ; i < nEvents ; i++ )
				{
					if ( pEvents[i].dwTick > dwTick )
					{
						memmove(&pEvents[i+1],&pEvents[i],sizeof(MIDI_MASTER_EVENTS)*(nEvents-i));
						break;
					}
				}
#else
				int i = nEvents-1;
				for ( ; i >= 0 ; i-- )
				{
					if ( pEvents[i].dwTick <= dwTick )
					{
						i++;
						memmove(&pEvents[i+1],&pEvents[i],sizeof(MIDI_MASTER_EVENTS)*(nEvents-i));
						break;
					}
				}
				if ( i == -1 )
					i  = nEvents;
#endif
				ptr = strchr(ptr,'=');
				if ( !ptr )
					break;
				ptr++;
				pEvents[i].dwTick = dwTick;
				pEvents[i].dwData = atoi(ptr) | 0xff000000;
				ptr = strchr(ptr,'\n');
				if ( !ptr )
					break;
				nEvents++;
				ptr++;
				dwSize -= ptr - szToken;
			}
		}
		else if ( !strnicmp(ptr,"[Beat]\n",7) )
		{
			dwSize -= 7;
			ptr += 7;
			nAllocEvents = nEvents + SectionLineCounts(ptr);
			if ( pEvents )
				pEvents = (MIDI_MASTER_EVENTS*)realloc(pEvents,sizeof(MIDI_MASTER_EVENTS)*nAllocEvents);
			else
				pEvents = (MIDI_MASTER_EVENTS*)malloc(sizeof(MIDI_MASTER_EVENTS)*nAllocEvents);

			while ( dwSize )
			{
				if ( *ptr == '[' )
					break;

				char* szToken = ptr;
				DWORD dwTick = atoi(ptr);
#if	1
				int i = 0;
				for ( ; i < nEvents ; i++ )
				{
					if ( pEvents[i].dwTick > dwTick )
					{
						memmove(&pEvents[i+1],&pEvents[i],sizeof(MIDI_MASTER_EVENTS)*(nEvents-i));
						break;
					}
				}
#else
				int i = nEvents-1;
				for ( ; i >= 0 ; i-- )
				{
					if ( pEvents[i].dwTick <= dwTick )
					{
						i++;
						memmove(&pEvents[i+1],&pEvents[i],sizeof(MIDI_MASTER_EVENTS)*(nEvents-i));
						break;
					}
				}
				if ( i == -1 )
					i  = nEvents;
#endif
				ptr = strchr(ptr,'=');
				if ( !ptr )
					break;
				ptr++;
				DWORD dwBeat = atoi(ptr);
				ptr = strchr(ptr,'/');
				if ( !ptr )
					break;
				ptr++;
				DWORD dwBeatBase = atoi(ptr);
				if ( dwBeatBase&(dwBeatBase-1) )
					break;
				DWORD dwBeatIdx = 0;
				while ( dwBeatBase >>= 1 )
					dwBeatIdx++;
				ptr = strchr(ptr,'\n');
				if ( !ptr )
					break;

				pEvents[i].dwTick = dwTick;
				pEvents[i].dwData = (dwBeat <<8) | dwBeatIdx;
				nEvents++;

				ptr++;
				dwSize -= ptr - szToken;
			}
		}
		else if ( !strnicmp(ptr,"[Tracks]\n",9) )
		{
			dwSize -= 9;
			ptr += 9;

			DWORD written;

			DWORD track_pos = SetFilePointer(hVSQ,0,NULL,FILE_CURRENT);
			char token[] = "MTrk\0\0\0\0\0\xff\3\xcMaster Track";
			WriteFile(hVSQ,token,sizeof(token)-1,&written,NULL);

			DWORD dwPrevTick = 0;
			for ( int i = 0 ; i < nEvents ; i++ )
			{
				DWORD dwTick = pEvents[i].dwTick - dwPrevTick;
				dwPrevTick = pEvents[i].dwTick;

	BYTE tick_byte[8];
	DWORD dwValue = dwTick;
	size_t len = 0;
	do
	{
		dwValue >>= 7;
		len++;
	} while ( dwValue );
	BYTE base = 0;
	for ( int j = len-1 ; j >= 0 ; j-- )
	{
		tick_byte[j] = (BYTE)dwTick & 0x7f | base;
		dwTick >>= 7;
		base = 0x80;
	}
	WriteFile(hVSQ,&tick_byte,len,&written,NULL);

				if ( pEvents[i].dwData & 0xff000000 )
				{
					char token2[] = "\xff\x51\3\0\0\0";
					token2[3] = pEvents[i].dwData >> 16;
					token2[4] = pEvents[i].dwData >> 8;
					token2[5] = pEvents[i].dwData;
					WriteFile(hVSQ,token2,sizeof(token2)-1,&written,NULL);
					if ( written != sizeof(token2)-1 )
					{
						if ( pEvents )
							free(pEvents);
						return FALSE;
					}
				}
				else
				{
					char token2[] = "\xff\x58\4\0\0\x18\x8";
					token2[3] = pEvents[i].dwData >> 8;
					token2[4] = pEvents[i].dwData;
					WriteFile(hVSQ,token2,sizeof(token2)-1,&written,NULL);
					if ( written != sizeof(token2)-1 )
					{
						if ( pEvents )
							free(pEvents);
						return FALSE;
					}
				}
			}

			char token2[] = "\0\xff\x2f\0";
			WriteFile(hVSQ,token2,sizeof(token2)-1,&written,NULL);
			if ( written != sizeof(token2)-1 )
			{
				if ( pEvents )
					free(pEvents);
				return FALSE;
			}

			DWORD track_size = SetFilePointer(hVSQ,0,NULL,FILE_CURRENT) - track_pos - 8;
			SetFilePointer(hVSQ,track_pos+4,NULL,FILE_BEGIN);
			BYTE track_sizeX[4];
			track_sizeX[0] = track_size >> 24;
			track_sizeX[1] = track_size >> 16;
			track_sizeX[2] = track_size >> 8;
			track_sizeX[3] = track_size;
			WriteFile(hVSQ,track_sizeX,4,&written,NULL);
			if ( written != 4 )
			{
				if ( pEvents )
					free(pEvents);
				return FALSE;
			}
			SetFilePointer(hVSQ,0,NULL,FILE_END);

			while ( dwSize )
			{
				if ( *ptr == '[' )
					break;

				char* szToken = ptr;
				ptr = (char*)_mbschr((const unsigned char*)ptr,'\n');
				if ( !ptr )
				{
					if ( pEvents )
						free(pEvents);
					return 0;
				}
				*(ptr++) = '\0';
				char* szToken2 = (char*)_mbsrchr((const unsigned char*)szToken,'=');
				if ( ptr < szToken2 )
				{
					if ( pEvents )
						free(pEvents);
					return 0;
				}
				*(szToken2++) = '\0';

				HANDLE hTXT = CreateFile(szToken2, GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
				WriteTrackText(hTXT,szToken,hVSQ);
				CloseHandle(hTXT);

				if ( fTemp )
					DeleteFile(szToken2);

				tracks++;
				dwSize -= ptr - szToken;
			}
		}
		else
		{
			if ( pEvents )
				free(pEvents);
			return 0;
		}
	}

	if ( pEvents )
		free(pEvents);

	return tracks;
}

BOOL VXT2VSQ(char* szInput,char* szOutput,BOOL fTemp)
{
	DWORD red = 0;

	char szInputFile[MAX_PATH];
	strcpy(szInputFile,szInput);

	HANDLE hVXT = CreateFile(szInput, GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	DWORD dwSize = GetFileSize(hVXT,NULL);
	char* szVXTText = (char*)malloc(dwSize+1);
	ReadFile(hVXT,szVXTText,dwSize,&red,NULL);
	szVXTText[dwSize] = '\0';
	CloseHandle(hVXT);

	char szCurrentPath[MAX_PATH];
	GetCurrentDirectory(MAX_PATH,szCurrentPath);

	char *szFilePath = (char*)_mbsrchr((const unsigned char*)szInputFile,'\\');
	if ( szFilePath )
	{
		*szFilePath = '\0';
		SetCurrentDirectory(szInputFile);
	}
	
	HANDLE hVSQ = CreateFile(szOutput, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	int tracks = VXT2VSQInternal(szVXTText,dwSize,hVSQ,fTemp);

	SetFilePointer(hVSQ,11,NULL,FILE_BEGIN);
	DWORD written;
	WriteFile(hVSQ,&tracks,1,&written,NULL);

	CloseHandle(hVSQ);

	free(szVXTText);

	SetCurrentDirectory(szCurrentPath);

	if ( fTemp )
		DeleteFile(szInput);

	return TRUE;
}

char* ReadTrackText(HANDLE hInput,HANDLE hTxt)
{
	static char szTrack[36];

	BYTE buf[256];
	DWORD red = 0;
	DWORD written = 0;
	DWORD dwSize;

	ReadFile(hInput,buf,8,&red,NULL);
	if ( memcmp(buf,"MTrk",4) || red != 8 )
		return NULL;

	dwSize = (((((buf[4] << 8) | buf[5]) << 8) | buf[6]) << 8) | buf[7];
	ReadFile(hInput,buf,4,&red,NULL);
	if ( red != 4 )
		return NULL;
	dwSize -= 4;
	if ( memcmp(buf,"\0\xff\3",3) )
		return NULL;

	ReadFile(hInput,szTrack,buf[3],&red,NULL);
	if ( red != buf[3] )
		return NULL;
	dwSize -= buf[3];
	szTrack[buf[3]] = '\0';

	int k = 0;
	while ( dwSize )
	{
		ReadFile(hInput,buf,4,&red,NULL);
		if ( red != 4 )
			return NULL;
		dwSize -= 4;
		if ( memcmp(buf,"\0\xff\1",3) )
			break;

		int j = buf[3];
		dwSize -= buf[3];
		ReadFile(hInput,buf,j,&red,NULL);
		if ( red != j )
			return NULL;

		char token[16];
		int n;
		if ( k < 10000 )
		{
			n = 8;
			sprintf(token,"DM:%04d:",k++);
		}
		else
		{
			n = 12;
			sprintf(token,"DM:%08d:",k++);
		}
		if ( memcmp(token,buf,n) )
			return NULL;

		WriteFile(hTxt,buf+n,j-n,&written,NULL);
	}
	SetFilePointer(hInput,dwSize,NULL,FILE_CURRENT);

	return szTrack;
}

BOOL WriteTempo(char *szMasterText,DWORD dwSize,HANDLE hVXT)
{
	char buf[32];
	DWORD written;

	const char tempo_header[] = "[Tempo]\n";
	WriteFile(hVXT,tempo_header,sizeof(tempo_header)-1,&written,NULL);
	if ( written != sizeof(tempo_header)-1 )
		return FALSE;

	BYTE *ptr = (BYTE*)szMasterText;
	int nEvents = 0;
	DWORD dwTick = 0;

	MIDI_MASTER_EVENTS* pEvents = (MIDI_MASTER_EVENTS*)malloc(sizeof(MIDI_MASTER_EVENTS)*dwSize/7);
	ZeroMemory(pEvents,sizeof(MIDI_MASTER_EVENTS)*dwSize/7);
	while ( dwSize )
	{
		DWORD dwDelta = 0;
		do
		{
			dwDelta = ( dwDelta << 7 ) | (*ptr & 0x7F);
			dwSize--;
		} while ( *(ptr++) >= 0x80 );
		dwTick += dwDelta;

		if ( *(ptr++) != 0xff )
		{
			free(pEvents);
			return FALSE;
		}

		switch ( *(ptr++) )
		{
			case 0x51:
				if ( *(ptr++) != 0x3 )
				{
					free(pEvents);
					return FALSE;
				}
				sprintf((char*)buf,"%d=%d\n",dwTick, ((ptr[0] << 8 | ptr[1]) << 8) | ptr[2]);
				ptr += 3;
				WriteFile(hVXT,buf,strlen((char*)buf),&written,NULL);
				dwSize -= 6;
				break;
			case 0x58:
				if ( *(ptr++) != 0x4 )
				{
					free(pEvents);
					return FALSE;
				}
				pEvents[nEvents].dwTick = dwTick;
				pEvents[nEvents++].dwData = *(DWORD*)ptr;
				ptr += 4;
				dwSize -= 7;
				break;
			case 0x2f:
				dwSize -= 3;
				break;
		}
	}

	const char beat_header[] = "[Beat]\n";
	WriteFile(hVXT,beat_header,sizeof(beat_header)-1,&written,NULL);

	for ( int i = 0 ; i < nEvents ; i++ )
	{
		BYTE Beats = pEvents[i].dwData & 0xff;
		BYTE BeatBase = 1 << (pEvents[i].dwData >> 8 & 0xff);
		sprintf((char*)buf,"%d=%d/%d\n",pEvents[i].dwTick,Beats,BeatBase);
		WriteFile(hVXT,buf,strlen((char*)buf),&written,NULL);
	}
	free(pEvents);

	return TRUE;
}

BOOL VSQ2VXTInternal(HANDLE hInput,char* szOutput,int nEditTrack)
{
	char szOutputFile[MAX_PATH];

	int tracks = 0;
	int timeFormat = 480;
	int tempo = 50000;
	int Beats = 4;
	int Quarter=2;
	int Ticks=24;

	BYTE buf[256];
	DWORD red = 0;
	ReadFile(hInput,buf,14,&red,NULL);
	if ( red != 14 )
		return FALSE;

	const char smf_file_header[] = "MThd\0\0\0\6\0\1";
	if ( memcmp(buf,smf_file_header,sizeof(smf_file_header)-1) )
		return FALSE;

	tracks = buf[11];
	timeFormat = (buf[12] << 8) | buf[13];

	ReadFile(hInput,buf,4,&red,NULL);
	if ( memcmp(buf,"MTrk",4) || red != 4 )
		return FALSE;

	ReadFile(hInput,buf,4,&red,NULL);
	DWORD dwSize = (((((buf[0] << 8 ) | buf[1]) << 8 ) | buf[2]) << 8 ) | buf[3];

	ReadFile(hInput,buf,16,&red,NULL);
	if ( memcmp(buf,"\0\xff\3\xcMaster Track",16) || red != 16 )
		return FALSE;

	strcpy(szOutputFile,szOutput);
	strcat(szOutputFile,".vxt");
	HANDLE hVXT = CreateFile(szOutputFile, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if ( !hVXT )
		return FALSE;

	dwSize -= 16;
	char *szMasterText = (char*)malloc(dwSize);
	ReadFile(hInput,szMasterText,dwSize,&red,NULL);
	if ( red != dwSize )
	{
		free(szMasterText);
		return FALSE;
	}

	DWORD written = 0;
	sprintf((char*)buf,"[Master]\nTimeFormat=%d\n",timeFormat);
	WriteFile(hVXT,buf,strlen((char*)buf),&written,NULL);

	WriteTempo(szMasterText,dwSize,hVXT);

//	tempo = ((buf[28] << 8 | buf[29]) << 8) | buf[30];
//	Beats = buf[35];
//	Quarter = buf[36];
//	Ticks = buf[37];

	const char tracks_header[] = "[Tracks]\n";
	WriteFile(hVXT,tracks_header,sizeof(tracks_header)-1,&written,NULL);

	free(szMasterText);

	for ( int i = 1 ; i < tracks ; i++ )
	{
		if ( nEditTrack )
		{
#if	0
			MakeTempFileName(szOutputFile,"txt");
			if ( i == nEditTrack )
				strcpy(txt_file,szOutputFile);
#else
			if ( i == nEditTrack )
			{
				strcpy(szOutputFile,szOutput);
				strcat(szOutputFile,".txt");
				strcpy(txt_file,szOutputFile);
			}
			else
				MakeTempFileName(szOutputFile,"txt");
#endif
		}
		else
		{
			sprintf((char*)buf,"Track%d.txt",i);
			strcpy(szOutputFile,szOutput);
			strcat(szOutputFile,(char*)buf);
		}

		char *szTrackShort = (char*)_mbsrchr((const unsigned char*)szOutputFile,'\\');
		if ( !szTrackShort )
			szTrackShort = szOutputFile;
		else
			szTrackShort++;

		HANDLE hTxt = CreateFile(szOutputFile, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		if ( !hTxt )
		{
			CloseHandle(hVXT);
			return FALSE;
		}

		char* szTrackName = ReadTrackText(hInput,hTxt);
		CloseHandle(hTxt);
		if ( szTrackName )
		{
			WriteFile(hVXT,szTrackName,strlen(szTrackName),&written,NULL);
			WriteFile(hVXT,"=",1,&written,NULL);
			WriteFile(hVXT,szTrackShort,strlen(szTrackShort),&written,NULL);
			WriteFile(hVXT,"\n",1,&written,NULL);
		}
		else
		{
			CloseHandle(hVXT);
			return FALSE;
		}
	}

	CloseHandle(hVXT);

	return TRUE;
}

BOOL VSQ2VXT(char* szInput,char* szOutput,int nEditTrack)
{
	BOOL fSuc = FALSE;
	HANDLE hFile = CreateFile(szInput, GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if ( !hFile )
		return FALSE;

	char *szTemp = strdup(szOutput);
	int len = strlen(szTemp);
	szTemp[len-4] = '\0';
	VSQ2VXTInternal(hFile,szTemp,nEditTrack);
	free(szTemp);

	CloseHandle(hFile);
	return fSuc;
}

BOOL EditText(char* szTextFile)
{
	char szExe[MAX_PATH];
	sprintf( szExe, "%s \"%s\"", szEditor, szTextFile );

	FILETIME ftBefore;
	FILETIME ftAfter;
	SYSTEMTIME stCheck;
	HANDLE hFile = CreateFile(szTextFile, GENERIC_READ|GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	GetSystemTime(&stCheck);
	SystemTimeToFileTime(&stCheck,&ftBefore);
	ftBefore.dwLowDateTime-0x1000000;
	SetFileTime(hFile,NULL,NULL,&ftBefore);
	GetFileTime(hFile,NULL,NULL,&ftBefore);
	CloseHandle(hFile);

	PROCESS_INFORMATION	pi;
	STARTUPINFO si;
	ZeroMemory(&si,sizeof(si));
	si.cb=sizeof(si);
//	si.dwFlags = STARTF_USESHOWWINDOW;
//	si.wShowWindow = wShowWindow;

	CreateProcess(NULL,szExe,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS,NULL,NULL,&si,&pi);
	WaitForInputIdle(pi.hProcess,IDOL_WAIT);
	WaitForSingleObject(pi.hProcess,INFINITE);

	DWORD dwExitCode;
	GetExitCodeProcess( pi.hProcess, &dwExitCode );

	CloseHandle(pi.hProcess);
	CloseHandle(pi.hThread);

	hFile = CreateFile(szTextFile, GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	GetFileTime(hFile,NULL,NULL,&ftAfter);
	CloseHandle(hFile);

	if ( memcmp(&ftBefore,&ftAfter,sizeof(FILETIME)) )
		return TRUE;

	return FALSE;
}
