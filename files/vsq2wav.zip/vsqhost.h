// VSQ SIMPLE? HOST

#include "pluginterfaces/vst2.x/aeffectx.h"

#include <mmsystem.h>
#pragma comment(lib,"winmm")

struct MIDI_EVENT
{
public:
	DWORD time_code;
	MIDI_EVENT *pNext;

	DWORD	dwDataSize;
	BYTE	dwOffset;
	BYTE*	pMidiEvent;
};

struct VST_PLUGIN
{
	HMODULE hModule;
	AEffect* pEffect;
};

typedef AEffect* (*PluginEntryProc) (audioMasterCallback audioMaster);
static VstIntPtr VSTCALLBACK HostCallback (AEffect* effect, VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float opt);

class VsqHost
{
public:
	VsqHost();
	~VsqHost();

	BOOL ReadVSQFile(TCHAR *szFile);
	BOOL LoadVST(TCHAR *tszFileName);
	BOOL Render(int nTrack,TCHAR* tszFileName);

	int getFormat();
	int getTimeFormat();
	int getTrackCounts();

private:
	// MIDI
	MIDI_EVENT* merge_events(MIDI_EVENT*,MIDI_EVENT*);
	BOOL free_events(MIDI_EVENT*);
	BOOL free_smf();
	MIDI_EVENT* clone_event(MIDI_EVENT* pEvent);
	MIDI_EVENT* copy_event(MIDI_EVENT* x);
	size_t getVariableValue(BYTE* pData,DWORD *pValue);
	int getMidiEventDataSize(BYTE event_code);
	WORD getBigWORD(BYTE* pData);
	double DeltaToMilliSecond(DWORD dwDelta,DWORD dwTempo);
	DWORD MilliSecondToTick(DWORD dwDelta,DWORD dwTempo);

	// VST
	VstIntPtr dispatch_VST_command(VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float opt);
	VST_PLUGIN* m_pVSQPlugIn;

	//
	int m_nSMFformat;
	int m_nTimeFormat;
	int m_nTracks;
	MIDI_EVENT** m_nTrackEvents;
	int m_nVocaloidVer;
};
