#include "stdafx.h"

#include "vsqhost.h"

#include <assert.h>

VsqHost::VsqHost() : m_pVSQPlugIn(NULL),m_nTracks(0),m_nTrackEvents(NULL),m_nVocaloidVer(-1)
{
}

VsqHost::~VsqHost()
{
	if ( m_pVSQPlugIn && m_pVSQPlugIn->hModule )
		dispatch_VST_command(effClose, 0, 0, 0, 0);
	free_smf();
}

/* vsq�ɂ́A0xf?,0xb?�����Ȃ����ǥ�� */
int VsqHost::getMidiEventDataSize(BYTE event_code)
{
	switch ( event_code >> 4 )
	{
		case 0xe:	/* �s�b�`�x���h �`�F���W */
		case 0xa:	/* �|���t�H�j�b�N �L�[�v���b�V�� */
		case 0xb:	/* Control Change */
		case 0x8:	/* Note Off */
		case 0x9:	/* Note On */
			return 2;
		case 0xd:	/* �`�����l�� �v���b�V�� */
		case 0xc:	/* Program Change */
			return 1;
		case 0xf:
			switch ( event_code & 0xf )
			{
				case 0xf:		/* Meta */
					return -1;
				case 0x0:		/* Exclusive */
				case 0x7:		/* Exclusive */
					return 0;
				default:
					assert(0);
			}
			break;
		default:
			assert(0);
	}
	return 0;
}

DWORD getBigDWORD(BYTE* pData)
{
	return pData[3] + (pData[2]<<8) + (pData[1]<<16) + (pData[0]<<24);
}

WORD VsqHost::getBigWORD(BYTE* pData)
{
	return pData[1] + (pData[0]<<8);
}

size_t VsqHost::getVariableValue(BYTE* pData,DWORD *pValue)
{
	size_t size = 0;
	*pValue = 0;
	do
	{
		*pValue = ( (*pValue) << 7 ) | (*pData & 0x7F);
		size++;
	} while ( *(pData++) >= 0x80 );

	return size;
}

MIDI_EVENT* VsqHost::clone_event(MIDI_EVENT* pEvent)
{
	MIDI_EVENT* pNewEvent = new MIDI_EVENT;
	pNewEvent->time_code = pEvent->time_code;
	pNewEvent->dwDataSize = pEvent->dwDataSize;
	pNewEvent->dwOffset	= pEvent->dwOffset;
	pNewEvent->pMidiEvent = new BYTE[pEvent->dwDataSize+pEvent->dwOffset];
	memcpy( pNewEvent->pMidiEvent, pEvent->pMidiEvent, pEvent->dwDataSize+pEvent->dwOffset );
	pNewEvent->pNext = NULL;
	return pNewEvent;
}

MIDI_EVENT* VsqHost::copy_event(MIDI_EVENT* x)
{
	MIDI_EVENT z;
	MIDI_EVENT *p = &z;

	while( x )
	{
		p->pNext = clone_event(x);
		p = p->pNext;
		x = x->pNext;
	}
	
	return z.pNext;
}

MIDI_EVENT* VsqHost::merge_events(MIDI_EVENT* x0,MIDI_EVENT* y0)
{
	MIDI_EVENT *x = copy_event(x0);
	MIDI_EVENT *y = copy_event(y0);
	MIDI_EVENT z;
	MIDI_EVENT *p = &z;

	while( x && y )
	{
		if( x->time_code <= y->time_code )
		{
			p->pNext = x;
			p = x;
			x = x->pNext;
		}
		else
		{
			p->pNext = y;
			p = y;
			y = y->pNext;
		}
	}
	
	if( x )
		p->pNext = x;
	else
		p->pNext = y;
	
	return z.pNext;
}

BOOL VsqHost::free_events(MIDI_EVENT* pEvent)
{
	MIDI_EVENT* pEventTmp;
	while ( pEvent )
	{
		pEventTmp = pEvent->pNext;
		delete pEvent->pMidiEvent;
		delete pEvent;
		pEvent = pEventTmp;
	}
	return TRUE;
}

BOOL VsqHost::free_smf()
{
	for ( int i = 0 ; i < m_nTracks ; i++ )
		free_events(m_nTrackEvents[i]);
	delete m_nTrackEvents;
	return TRUE;
}

BOOL VsqHost::ReadVSQFile(TCHAR *szFileName)
{
	DWORD dwAccBytes;
	BYTE buf[1024];		/* �K���ȃo�b�t�@ */

	HANDLE hFile = CreateFile(szFileName, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if ( !hFile )
		return NULL;

	ReadFile(hFile, buf, 8, &dwAccBytes, NULL);
	if ( dwAccBytes != 8 || memcmp(buf,"MThd",4) )
	{
		CloseHandle(hFile);
		return NULL;
	}

	DWORD dwSize = getBigDWORD(&buf[4]);
	if ( dwSize != 6 )
	{
		CloseHandle(hFile);
		return NULL;
	}

	ReadFile(hFile, buf, dwSize, &dwAccBytes, NULL);
	if ( dwAccBytes != dwSize )
	{
		CloseHandle(hFile);
		return NULL;
	}

	m_nSMFformat = getBigWORD(&buf[0]);
	m_nTracks = getBigWORD(&buf[2]);
	m_nTimeFormat = getBigWORD(&buf[4]);

	m_nTrackEvents = new MIDI_EVENT*[m_nTracks];
	for ( int i = 0 ; i < m_nTracks; i++ )
	{
		MIDI_EVENT* pPrevEvents = NULL;

		ReadFile(hFile, buf, 8, &dwAccBytes, NULL);
		assert( dwAccBytes == 8 );
		assert( !memcmp(buf,"MTrk",4) );

		dwSize = getBigDWORD(&buf[4]);
		BYTE *pData = (BYTE*)LocalAlloc(LMEM_FIXED,dwSize);
		assert( pData );

		ReadFile(hFile, pData, dwSize, &dwAccBytes, NULL);
		assert( dwAccBytes == dwSize );

		DWORD time = 0;
		BYTE *pLast = pData + dwSize;
		BYTE *pCur = pData;
		BYTE running_status = 0;
		while ( pCur < pLast )
		{
			DWORD delta_time;

			pCur += getVariableValue(pCur,&delta_time);
			time += delta_time;

			MIDI_EVENT* pEvent = NULL;

			BOOL fRemoveStatus = FALSE;
			BYTE *pTokenStart = pCur;
			BYTE event_code = *(pCur++);

			/* vsq�ɂ́A�m�[�g�C�x���g�Ȃ����ǥ�� */
			if ( event_code < 0x80 )
			{
				assert(running_status);
				event_code = running_status;
				fRemoveStatus = TRUE;
			}

			int event_size = getMidiEventDataSize(event_code);
			if ( event_size > 0 )
			{
				dwSize = event_size;
				if ( fRemoveStatus )
					dwSize--;
				pCur += dwSize;
				running_status = event_code;
			}
			else
			{
				DWORD dwVariableLen;
				pCur += getVariableValue(&pCur[-event_size],&dwVariableLen);
				pCur += dwVariableLen - event_size;
				running_status = 0;
			}

			DWORD dwSize = (DWORD)(pCur - pTokenStart);
			pEvent = new MIDI_EVENT;
			pEvent->pNext = NULL;
			pEvent->time_code = time;
			pEvent->dwDataSize = dwSize;
			pEvent->dwOffset = *pTokenStart < 0x80 ? 1 : 0;
			pEvent->pMidiEvent = new BYTE[dwSize+pEvent->dwOffset];
			pEvent->pMidiEvent[0] = event_code;
			memcpy( &pEvent->pMidiEvent[pEvent->dwOffset], pTokenStart, dwSize );

			// ���^�e�L�X�g�C�x���g����o�[�W�����̎擾
			if ( event_code == 0xff && pTokenStart[1] == 0x01 )
			{
				char* ptr = strstr((char*)pTokenStart+3,"Version=");
				if ( ptr )
				{
					if ( !strncmp(ptr+8,"DSB301",6) )
						m_nVocaloidVer = 2;
					else if ( !strncmp(ptr+8,"DSB202",6) )
						m_nVocaloidVer = 1;
				}
			}

			if ( pPrevEvents )
				pPrevEvents->pNext = pEvent;
			else
				m_nTrackEvents[i] = pEvent;
			pPrevEvents = pEvent;
		}

		LocalFree(pData);
	}

	CloseHandle(hFile);

	return TRUE;
}

double VsqHost::DeltaToMilliSecond(DWORD dwDelta,DWORD dwTempo)
{
	return (dwDelta*((double)dwTempo/1000.0))/(double)m_nTimeFormat;
}

DWORD VsqHost::MilliSecondToTick(DWORD dwDelta,DWORD dwTempo)
{
	return (DWORD)((double)m_nTimeFormat*(double)dwDelta*1000.0/(double)dwTempo);
}

int VsqHost::getFormat()
{
	return m_nSMFformat;
}

int VsqHost::getTimeFormat()
{
	return m_nTimeFormat;
}

int VsqHost::getTrackCounts()
{
	return m_nTracks;
}

VstIntPtr VSTCALLBACK HostCallback (AEffect* effect, VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float opt)
{
	VstIntPtr result = 0;

	switch (opcode)
	{
		case audioMasterVersion :
			result = kVstVersion;
			break;
	}

	return result;
}

BOOL VsqHost::LoadVST(TCHAR *tszFileName)
{
	TCHAR tszVSTPlugin[MAX_PATH];
	if ( !tszFileName )
	{
		HKEY hKey;
		TCHAR lpszName[64];
		DWORD dwNameSize;
		LONG lRes;
		FILETIME ft;

		TCHAR *tszProductRegKey,*tszProductVSTi;
		TCHAR *tszDemoRegKey,*tszDemoVSTi;
		switch ( m_nVocaloidVer )
		{
			case 1:
				tszProductRegKey = TEXT("SOFTWARE\\VOCALOID\\APPLICATION");
				tszDemoRegKey = NULL;
				tszProductVSTi = TEXT("\\vocaloid.dll");
				tszDemoVSTi = NULL;
				break;
			case 2:
				tszProductRegKey = TEXT("SOFTWARE\\VOCALOID2\\APPLICATION");
				tszDemoRegKey = TEXT("SOFTWARE\\VOCALOID2_DEMO\\APPLICATION");
				tszProductVSTi = TEXT("\\vocaloid2.dll");
				tszDemoVSTi = TEXT("\\vocaloid2_demo.dll");
				break;
			default:
				return FALSE;
		}

		LONG ret = RegOpenKeyEx(HKEY_LOCAL_MACHINE, tszProductRegKey, 0, KEY_READ, &hKey);
		if ( ret != ERROR_SUCCESS )
		{
			if ( !tszDemoRegKey )
				return FALSE;
			LONG ret = RegOpenKeyEx(HKEY_LOCAL_MACHINE, tszDemoRegKey, 0, KEY_READ, &hKey);
			if ( ret != ERROR_SUCCESS )
				return FALSE;
		}
		for ( DWORD i = 0;; i++ )
		{
			*tszVSTPlugin = TEXT('\0');
			dwNameSize = sizeof(lpszName)/sizeof(TCHAR);
			lRes = RegEnumKeyEx(hKey,i,lpszName,&dwNameSize,NULL,NULL,NULL,&ft);
			if ( lRes != ERROR_SUCCESS )
			   break;

			HKEY hChildKey;
			LONG ret = RegOpenKeyEx(hKey, lpszName, 0, KEY_READ, &hChildKey);
			if ( ret != ERROR_SUCCESS )
				continue;

			DWORD dwType = REG_SZ;
			DWORD dwSize = MAX_PATH;
			ret = RegQueryValueEx(hChildKey, TEXT("PATH"), NULL, &dwType, (LPBYTE)tszVSTPlugin, &dwSize);
			RegCloseKey(hChildKey);
			if ( ret != ERROR_SUCCESS )
				continue;
			
			// ���i��
			if ( _tcsstr(tszVSTPlugin,tszProductVSTi) )
				break;
			// �f���ŁH
			if ( tszDemoVSTi && _tcsstr(tszVSTPlugin,tszDemoVSTi) )
				break;
		}
		RegCloseKey(hKey);
		if ( !*tszVSTPlugin )
			return FALSE;
		tszFileName = tszVSTPlugin;
	}

	HMODULE hPlugin = LoadLibrary (tszFileName);

	PluginEntryProc mainProc = (PluginEntryProc)GetProcAddress (hPlugin, "VSTPluginMain");
	if (!mainProc)
			mainProc = (PluginEntryProc)GetProcAddress (hPlugin, "main");

	if (!mainProc)
		return FALSE;

	m_pVSQPlugIn = new VST_PLUGIN;
	m_pVSQPlugIn->hModule = hPlugin;
	m_pVSQPlugIn->pEffect = mainProc(HostCallback);

	dispatch_VST_command(effOpen, 0, 0, 0, 0);

	return TRUE;
}

VstIntPtr VsqHost::dispatch_VST_command(VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float opt)
{
	m_pVSQPlugIn->pEffect->dispatcher (m_pVSQPlugIn->pEffect, opcode, index, value, ptr, opt);
	return 0;
}

BOOL VsqHost::Render(int nTrack, TCHAR* tszFileName)
{
	// VSTi�Ȃ�
	if ( !m_pVSQPlugIn || !m_pVSQPlugIn->hModule )
		return FALSE;

	const float kSampleRate = 44100.0f;
	const DWORD sampleFrames = (DWORD)kSampleRate;

	WAVEFORMATEX wf;
	wf.nChannels       = 2;
	wf.wFormatTag      = WAVE_FORMAT_PCM;
	wf.wBitsPerSample  = 16;
	wf.nBlockAlign     = wf.nChannels*wf.wBitsPerSample/8;
	wf.nSamplesPerSec  = sampleFrames;
	wf.nAvgBytesPerSec = wf.nSamplesPerSec*wf.nBlockAlign;

	// Create WAV
	HMMIO hmmio = mmioOpen(tszFileName, NULL, MMIO_CREATE | MMIO_WRITE);
	if ( !hmmio )
		return FALSE;
	MMCKINFO mmckRiff,mmckData,mmckFmt;
	mmckRiff.fccType = mmioStringToFOURCC(TEXT("WAVE"), 0);
	mmioCreateChunk(hmmio, &mmckRiff, MMIO_CREATERIFF);
	mmckFmt.ckid = mmioStringToFOURCC(TEXT("fmt "), 0);
	mmioCreateChunk(hmmio, &mmckFmt, 0);
	mmioWrite(hmmio, (char *)&wf, sizeof(WAVEFORMATEX));
	mmioAscend(hmmio, &mmckFmt, 0);

	mmckData.ckid = mmioStringToFOURCC(TEXT("data"), 0);
	mmioCreateChunk(hmmio, &mmckData, 0);

	MIDI_EVENT *lpEvents = merge_events(m_nTrackEvents[0],m_nTrackEvents[nTrack]);
	MIDI_EVENT* current = lpEvents;

	float* left_ch = new float[sampleFrames];
	float* right_ch = new float[sampleFrames];
	float* out_buffer[] = { left_ch, right_ch };

	DWORD* wave_bufs;
	wave_bufs = new DWORD[sampleFrames];
	
	dispatch_VST_command(effSetSampleRate, 0, 0, 0, kSampleRate);
	dispatch_VST_command(effMainsChanged, 0, 1, 0, 0);
	dispatch_VST_command(effSetBlockSize, 0, sampleFrames, 0, 0);

	DWORD dwTempo = 500000;

	DWORD dwNow = 0;
	DWORD dwPrev = 0;
	DWORD dwDelta;
	DWORD dwDelay = sampleFrames;
	int addr_msb,addr_lsb;
	int data_msb,data_lsb;
	DWORD dwLength = 0;

	MIDI_EVENT* pWork = m_nTrackEvents[nTrack];

	while ( -1 )
	{
		MIDI_EVENT* pProcessEvent = current;
		int nEvents = 0;

		while ( current->time_code == dwNow )
		{
			if ( (pWork->pMidiEvent[0] & 0xf0) == 0xb0 )
			{
				switch ( current->pMidiEvent[1] )
				{
					case 0x63:
						addr_msb = current->pMidiEvent[2];
						addr_lsb = 0;
						break;
					case 0x62:
						addr_lsb = current->pMidiEvent[2];
						break;
					case 0x06:
						data_msb = current->pMidiEvent[2];
						break;
					case 0x26:
						data_lsb = current->pMidiEvent[2];
						// Duration in millisec
						if ( addr_msb == 0x50 && addr_lsb == 0x1 )
						{
							int len = data_msb << 7 | data_lsb;
							dwLength = (DWORD)(len*sampleFrames/1000.0);
						}
						break;
				}
			}
			nEvents++;
			current = current->pNext;
			if ( !current )
				break;
		}

		dwDelta = (DWORD)(DeltaToMilliSecond(dwNow-dwPrev,dwTempo)*sampleFrames/1000.0);

		VstEvents* pVSTEvents = (VstEvents*)malloc (sizeof(VstEvents) + nEvents*sizeof(VstEvent*));
		pVSTEvents->numEvents = 0;
		pVSTEvents->reserved = NULL;

		for ( int i = 0 ; i < nEvents ; i++ )
		{
			BYTE event_code = pProcessEvent->pMidiEvent[0];
			VstEvent* pVSTEvent = NULL;

			VstMidiEvent* pMidiEvent;

			switch ( event_code )
			{
				case 0xff:
					//���^�C�x���g�̏���
					switch ( pProcessEvent->pMidiEvent[1] )
					{
						case 0x51:
							dwTempo = (DWORD)(pProcessEvent->pMidiEvent[5] | (pProcessEvent->pMidiEvent[4] << 8) | (pProcessEvent->pMidiEvent[3] << 16));
							break;
					}
					break;
				case 0xf0:
				case 0xf7:
					break;
				default:
					pMidiEvent = (VstMidiEvent*)malloc(sizeof(VstMidiEvent) + pProcessEvent->dwDataSize*sizeof(BYTE));
					pMidiEvent->byteSize = sizeof(VstMidiEvent);
					pMidiEvent->deltaFrames = dwDelta;
					pMidiEvent->detune = 0;
					pMidiEvent->flags = 1;
					pMidiEvent->noteLength = 0;
					pMidiEvent->noteOffset = 0;
					pMidiEvent->noteOffVelocity = 0;
					pMidiEvent->reserved1 = 0;
					pMidiEvent->reserved2 = 0;
					pMidiEvent->type = kVstMidiType;
					memcpy(&pMidiEvent->midiData,&pProcessEvent->pMidiEvent[pProcessEvent->dwOffset],pProcessEvent->dwDataSize);
					pVSTEvents->events[pVSTEvents->numEvents++] = (VstEvent*)pMidiEvent;
					break;
			}
			pProcessEvent = pProcessEvent->pNext;
		}
		m_pVSQPlugIn->pEffect->dispatcher (m_pVSQPlugIn->pEffect, effProcessEvents, 0, 0, pVSTEvents, 0);

		for ( int i = 0 ; i < pVSTEvents->numEvents ; i++ )
			delete pVSTEvents->events[i];
		free(pVSTEvents);

		while ( dwDelta )
		{
			DWORD dwFrames = dwDelta > sampleFrames ?  sampleFrames : dwDelta;
			m_pVSQPlugIn->pEffect->processReplacing(m_pVSQPlugIn->pEffect, NULL, out_buffer, dwFrames);
			for ( size_t j = 0 ; j < dwFrames; j++ )
			{
				WORD right_chx = 32768 * out_buffer[0][j];
				WORD  left_chx = 32768 * out_buffer[1][j];
				wave_bufs[j] = MAKELONG(right_chx,left_chx);
			}
			dwDelta -= dwFrames;

			if ( dwDelay >= sampleFrames )
			{
				dwDelay -= sampleFrames;
				continue;
			}

			mmioWrite(hmmio, (char *)wave_bufs+dwDelay*sizeof(DWORD), (dwFrames-dwDelay)*sizeof(DWORD));
			mmioAscend(hmmio, &mmckData, 0);
			dwDelay = 0;
		}

		if ( !current )
			break;

		dwPrev = dwNow;
		dwNow = current->time_code;
	}

	while ( dwLength )
	{
		DWORD dwFrames = dwLength > sampleFrames ?  sampleFrames : dwLength;
		m_pVSQPlugIn->pEffect->processReplacing(m_pVSQPlugIn->pEffect, NULL, out_buffer, dwFrames);
		for ( size_t j = 0 ; j < dwFrames; j++ )
		{
			WORD right_chx = 32768 * out_buffer[0][j];
			WORD  left_chx = 32768 * out_buffer[1][j];
			wave_bufs[j] = MAKELONG(right_chx,left_chx);
		}
		dwLength -= dwFrames;

		mmioWrite(hmmio, (char *)wave_bufs, dwFrames*sizeof(DWORD));
		mmioAscend(hmmio, &mmckData, 0);
	}

	dispatch_VST_command(effMainsChanged, 0, 0, 0, 0);

	mmioAscend(hmmio, &mmckRiff, 0);
	mmioClose(hmmio, 0);

	free_events(lpEvents);

	return TRUE;
}
