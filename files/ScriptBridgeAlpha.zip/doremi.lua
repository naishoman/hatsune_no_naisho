-- doremi.jsのproxyスクリプトです。
require("ScriptBridge")

-- プラグインマニフェスト関数.
function manifest()
    myManifest = {
        name          = "ドレミJobプラグイン版",
        comment       = "歌詞を音階に変更します。",
        author        = "ないしょの人",
        pluginID      = "{783B9892-A1FF-4cde-AD66-C102DE90DF3A}",
        pluginVersion = "1.0.0.1",
        apiVersion    = "3.0.0.1"
    }
    
    return myManifest
end
