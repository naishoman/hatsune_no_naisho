-- vbtest.vbsのproxyスクリプトです。
require("ScriptBridge")
