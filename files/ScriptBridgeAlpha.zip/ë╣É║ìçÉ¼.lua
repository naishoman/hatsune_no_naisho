-- 音声合成.jsのproxyスクリプトです。
require("ScriptBridge")
