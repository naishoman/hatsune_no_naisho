// RemoteTest.cpp : �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"
#include "mmdagent.h"
#include "resource.h"

#include "../Plugin_Remote/Plugin_Remote.h"

// �O���[�o���ϐ�:

// ���b�Z�[�W �n���h���ł��B
INT_PTR CALLBACK MyDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	static HWND hAgent;
	HICON hIcon;

	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		hIcon = LoadIcon( (HINSTANCE)GetModuleHandle(0), MAKEINTRESOURCE(IDI_SMALL));
		SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
		AllocConsole();
		freopen("CONOUT$", "w", stdout);
		SetForegroundWindow(GetConsoleWindow());
		SetTimer(hDlg,1,100,NULL);
		return TRUE;

	case WM_TIMER:
		if ( hAgent && !IsWindow(hAgent) )
		{
			printf("Disconnect MMDAgent...\n");
			hAgent = NULL;
		}
		if ( !hAgent )
		{
			HWND hWnd = findAgent();
			if ( hWnd && registerClient(hDlg) )
			{
				printf("Connect MMDAgent...\n");
				hAgent = findAgent();
			}
		}
		return TRUE;

	case WM_DESTROY:
		FreeConsole();
		return TRUE;

	case WM_COPYDATA:
		{
			COPYDATASTRUCT* pcds = (COPYDATASTRUCT*)lParam;
			char* data = (char*)pcds->lpData;
			char* data2 = data+strlen(data)+1;
			printf("%s|%s\n",data,data2);
		}
		return TRUE;

	case WM_COMMAND:
		switch ( LOWORD(wParam) )
		{
			case IDOK:
				{
					HWND hEdit = GetDlgItem(hDlg,IDC_EDIT1);
					int len = GetWindowTextLengthA(hEdit);
					char* text = (char*)malloc(len+1);
					GetWindowTextA(hEdit,text,len+1);
					text[len] = '\0';
					char* cmd = strtok(text,"|");
					char* param = strtok(NULL,"");
					postRemoteMessage(WM_MMDAGENT_COMMAND,text,param);
					free(text);
					SetFocus(hEdit);
				}
				return TRUE;
			case IDCANCEL:
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_REMOTETEST), NULL, MyDlgProc);
}
