// Plugin_Remote.cpp : DLL �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"
#include "PluginHelper.h"

#include "Plugin_Remote.h"

#ifdef _MANAGED
#pragma managed(push, off)
#endif

#define MMDAGNT_IDENTIFY		TEXT("MMDAgent - Toolkit for building voice interaction systems")
#define WM_REGISTER_HWND		(WM_USER+101)

#define REMOTE_PLUGIN_CLASS		TEXT("REMOTE_PLUGIN")
#define REMOTE_PLUGIN_WNDNAME	TEXT("MSGWND")

HWND hClient = NULL;
HWND hMsgWnd = NULL;

LRESULT CALLBACK MsgWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_REGISTER_HWND:
			hClient = (HWND)wParam;
			break;

		case WM_COPYDATA:
			{
				COPYDATASTRUCT* pcds = (COPYDATASTRUCT*)lParam;
				char* data = (char*)pcds->lpData;
				const char* p2 = data+strlen(data)+1;
				postMessage((UINT)pcds->dwData,data,1,&p2);
			}
			return 0;

		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

BOOL CreateMsgWindow()
{
	if ( hMsgWnd )
		return FALSE;

	HINSTANCE hInstance = GetModuleHandle(NULL);

	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= MsgWndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= NULL;
	wcex.hCursor		= NULL;
	wcex.hbrBackground	= NULL;
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= REMOTE_PLUGIN_CLASS;
	wcex.hIconSm		= NULL;

	RegisterClassEx(&wcex);

	hMsgWnd = CreateWindow(REMOTE_PLUGIN_CLASS, REMOTE_PLUGIN_WNDNAME, WS_OVERLAPPEDWINDOW,
				CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

	if (!hMsgWnd)
	  return FALSE;

	UpdateWindow(hMsgWnd);

	return TRUE;
}

/* extAppStart: initialize controller */
void __stdcall extAppStart(MMDAgent *mmdagent)
{
	CreateMsgWindow();
}

void postRemoteMessage(HWND hWnd,UINT msg,char* cmd,int argc,char *argv[])
{
	size_t len = 0;
	len += strlen(cmd)+1;
	for ( int i = 0 ; i < argc ; i++ )
		len += strlen(argv[i])+1;

	char* ptr = (char*)malloc(len);
	char* p = ptr;
	strcpy(p,cmd);
	p += strlen(cmd)+1;
	for ( int i = 0 ; i < argc ; i++ )
	{
		strcpy(p,argv[i]);
		p += strlen(argv[i]);
		*(p++) = '|';
	}
	ptr[len-1] = '\0';

	COPYDATASTRUCT cds;
	cds.dwData = (DWORD)msg;
	cds.cbData = len;
	cds.lpData = ptr;

	SendMessage(hWnd,WM_COPYDATA, (WPARAM)NULL, (LPARAM)&cds);

	free(ptr);
}

// ���C���E�B���h�E�����p
BOOL CALLBACK EnumWindowsProc1(HWND hWnd, LPARAM lParam)
{
	TCHAR buf[256];
	GetWindowText(hWnd,buf,255);
	if ( _tcscmp(buf,MMDAGNT_IDENTIFY) )
		return TRUE;

	GetClassName(hWnd,buf,255);
	if ( _tcsncmp(buf,MMDAGNT_IDENTIFY,7) )
		return TRUE;

	*(HWND*)lParam = hWnd;
	return FALSE;
}

void procCommand(char* szMessage,int argc,char *argv[])
{
	if ( hClient )
		postRemoteMessage(hClient,WM_MMDAGENT_COMMAND,szMessage,argc,argv);
}

void procEvent(char* szMessage,int argc,char *argv[])
{
	if ( hClient )
		postRemoteMessage(hClient,WM_MMDAGENT_EVENT,szMessage,argc,argv);
}

void initPlugin(HWND hWnd)
{
	addCommandMessageHandler(procCommand);
	addEventMessageHandler(procEvent);
}

void termPlugin(HWND hWnd)
{
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			DisableThreadLibraryCalls(hModule);
			break;

		case DLL_PROCESS_DETACH:
		case DLL_THREAD_DETACH:
		case DLL_THREAD_ATTACH:
			break;
	}
    return TRUE;
}

//////////////// DLL���J�֐� /////////////////

/* MMDAgent��Window��T�� */
HWND findAgent()
{
	HWND hWnd = NULL;
	EnumWindows(EnumWindowsProc1,(LPARAM)&hWnd);
	return hWnd;
}

/* MMDAgent�ɃR�}���h/�C�x���g�𑗂� */
BOOL postRemoteMessage(UINT msg,char* cmd,char* param)
{
	// DLL����R�}���h���M
	HWND hMsgWnd = FindWindow(REMOTE_PLUGIN_CLASS,REMOTE_PLUGIN_WNDNAME);
	if  ( !hMsgWnd )
		return FALSE;

	if ( param )
		postRemoteMessage(hMsgWnd,msg,cmd,1,&param);
	else
		postRemoteMessage(hMsgWnd,msg,cmd,0,NULL);

	return TRUE;
}

/* MMDAgent����R�}���h/�C�x���g���󂯂�E�B���h�E��o�^����B */
BOOL registerClient(HWND hClient)
{
	// DLL����o�^
	HWND hMsgWnd = FindWindow(REMOTE_PLUGIN_CLASS,REMOTE_PLUGIN_WNDNAME);
	if  ( !hMsgWnd )
		return FALSE;

	PostMessage(hMsgWnd,WM_REGISTER_HWND,(WPARAM)hClient,0);
	return TRUE;
}

#ifdef _MANAGED
#pragma managed(pop)
#endif

