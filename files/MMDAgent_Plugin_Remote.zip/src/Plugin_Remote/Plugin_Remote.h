// Plugin_Remote.h
extern "C" HWND findAgent();
extern "C" BOOL postRemoteMessage(UINT msg,char* cmd,char* param);
extern "C" BOOL registerClient(HWND hClient);

