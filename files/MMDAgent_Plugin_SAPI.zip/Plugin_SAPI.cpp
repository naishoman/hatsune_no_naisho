// Plugin_SAPI.cpp : DLL �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"

#include <objbase.h>

#include <sapi.h>           // SAPI includes
#include <sphelper.h>
#include <spuihelp.h>

#include "PluginHelper.h"

#ifdef _MANAGED
#pragma managed(push, off)
#endif

/* ���d�l�̃��b�v�V���N���� */
//#define OLD_LIPSYNC

#define WM_SPEAK				(WM_USER+100)

#define PLUGINSAPI_STARTCOMMAND	"SYNTH_START"
#define PLUGINSAPI_STOPCOMMAND	"SYNTH_STOP"
#define PLUGINSAPI_EVENTSTART	"SYNTH_EVENT_START"
#define PLUGINSAPI_EVENTSTOP	"SYNTH_EVENT_STOP"

ISpVoice* pVoice = NULL;

ISpObjectToken* FindSAPIToken(char* szSpeaker)
{
	int len = MultiByteToWideChar(CP_ACP, 0, szSpeaker, -1, NULL,0);
	WCHAR* wszSpeaker = new WCHAR[len];
	MultiByteToWideChar(CP_ACP, 0, szSpeaker, -1, wszSpeaker, len );

    HRESULT hr;
    ISpObjectToken * pToken = NULL;
    IEnumSpObjectTokens* pEnum;
    hr = SpEnumTokens(SPCAT_VOICES, NULL, NULL, &pEnum);
    if (hr == S_OK)
    {
        bool fSetDefault = false;
        while (pEnum->Next(1, &pToken, NULL) == S_OK)
        {
            CSpDynamicString dstrDesc;
            hr = SpGetDescription(pToken, &dstrDesc);
            if (SUCCEEDED(hr))
            {
				if ( !wcscmp(dstrDesc,wszSpeaker) )
					break;
                pToken->Release();
				pToken = NULL;
            }
        }
    }

	pEnum->Release();
	delete[] wszSpeaker;

	return pToken;
}

void startSynth(int argc,char *argv[])
{
	/* SYNTH_START command */
	if ( argc == 3 )
	{
		ISpObjectToken * pToken = FindSAPIToken(argv[0]);
		if ( pToken )
		{
			pVoice->SetVoice( pToken );
			pToken->Release();
		}

		const char* event_args[] = {argv[0]};
		postEventMessage(PLUGINSAPI_EVENTSTART,1,event_args);

		const char* szSpeaker = (const char*)strdup(argv[0]);
		pVoice->SetNotifyWindowMessage( getMMDAgentWnd(), WM_SPEAK, 0, (LPARAM)szSpeaker );

		int len = MultiByteToWideChar(CP_ACP, 0, argv[2], -1, NULL,0);
		WCHAR* wszText = new WCHAR[len];
		MultiByteToWideChar(CP_ACP, 0, argv[2], -1, wszText, len );
		HRESULT hr = pVoice->Speak( wszText, SPF_IS_NOT_XML | SPF_ASYNC, 0 );
		delete[] wszText;
		if ( FAILED(hr) )
			postEventMessage(PLUGINSAPI_EVENTSTOP,1,event_args);
	}
}

void stopSynth(int argc,char *argv[])
{
	/* SYNTH_STOP command */
	pVoice->Speak( NULL , SPF_PURGEBEFORESPEAK , 0 );
}

void procSAPIEvent(WPARAM wParam, LPARAM lParam)
{
	CSpEvent cEvent;
	static char szSpeaker[MMDAGENT_MAXBUFLEN];

	while ( cEvent.GetFrom(pVoice) == S_OK )
	{
		switch(cEvent.eEventId)
		{
			case SPEI_START_INPUT_STREAM:
				strcpy(szSpeaker,(const char*)lParam);
				break;

			case SPEI_END_INPUT_STREAM:
				postEventMessage(PLUGINSAPI_EVENTSTOP,szSpeaker);
				break;

			case SPEI_VISEME:
				if ( cEvent.lParam > 0 )
				{
					/* �Ă��Ƃ��}�b�s���O */
					const WCHAR* viseme_tbl[] = {L"n",L"a",L"A",L"o",L"e",L"h",L"i",L"u",L"o",L"o",L"e",L"e",L"i",L"r",L"e",L"s",L"ch",L"th",L"f",L"d",L"g",L"b"};
					
					/* �Ă��Ƃ����b�v�V���N */
					char szLipSymbol[6];
#ifdef OLD_LIPSYNC
					sprintf(szLipSymbol,"%s200",viseme_tbl[cEvent.lParam]);
#else
					sprintf(szLipSymbol,"%s,150",viseme_tbl[cEvent.lParam]);
#endif
					const char* argv[] = {szSpeaker,szLipSymbol};
					postCommandMessage(MMDAGENT_COMMAND_LIPSYNCSTART,2,argv);
				}
				break;


			default:
				break;
		}
	}
}


void initPlugin(HWND hWnd)
{
	HRESULT hr = CoCreateInstance( CLSID_SpVoice, NULL, CLSCTX_INPROC_SERVER, IID_IUnknown, (void**)&pVoice );
	if ( FAILED(hr) )
		return;

	pVoice->SetInterest(SPFEI_ALL_TTS_EVENTS, SPFEI_ALL_TTS_EVENTS);

	addCommandMessageHandler(PLUGINSAPI_STARTCOMMAND,startSynth);
	addCommandMessageHandler(PLUGINSAPI_STOPCOMMAND,stopSynth);
	addMessageHandler(WM_SPEAK,procSAPIEvent);
}

void termPlugin(HWND hWnd)
{
	if ( pVoice )
		pVoice->Release();
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			DisableThreadLibraryCalls(hModule);
			CoInitialize(0);
			break;

		case DLL_PROCESS_DETACH:
			CoUninitialize();
			break;
		case DLL_THREAD_DETACH:
		case DLL_THREAD_ATTACH:
			break;
	}
    return TRUE;
}


#ifdef _MANAGED
#pragma managed(pop)
#endif

