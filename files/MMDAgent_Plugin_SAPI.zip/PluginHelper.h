#include "MMDAgent.h"
//#include "MMDAgent_command.h"

typedef void (*LPEVENT_FUNC)(int argc,char *argv[]);
typedef void (*LPEVENT_FUNC2)(char* szMessage,int argc,char *argv[]);
typedef void (*LPMSG_FUNC)(WPARAM wParam,LPARAM lParam);
typedef void (*LPMSG_FUNC2)(UINT uiMsg,WPARAM wParam,LPARAM lParam);

typedef struct _MSG_HANDLER
{
	const char* szMessage;
	union {
		LPEVENT_FUNC pFunc;
		LPEVENT_FUNC2 pFunc2;
	};
	struct _MSG_HANDLER* pNext;
} MSG_HANDLER;

typedef struct _MSG_HANDLER2
{
	UINT uiMsg;
	union {
		LPMSG_FUNC pFunc;
		LPMSG_FUNC2 pFunc2;
	};
	struct _MSG_HANDLER2* pNext;
} MSG_HANDLER2;

// mmdagent plugin helper
void postEventMessage(const char* szEvent,const char* szParam);
void postEventMessage(const char* szEvent,int argc,const char* argv[]);
void postCommandMessage(const char* szEvent,const char* szParam);
void postCommandMessage(const char* szEvent,int argc,const char* argv[]);
void postMessage(UINT msg,const char* szEvent,int argc,const char* argv[]);

void addCommandMessageHandler(const char* szEvent,LPEVENT_FUNC pFunc);
void addEventMessageHandler(const char* szEvent,LPEVENT_FUNC pFunc);
void addCommandMessageHandler(LPEVENT_FUNC2 pFunc2);
void addEventMessageHandler(LPEVENT_FUNC2 pFunc2);
void addMessageHandler(UINT uiMsg,LPMSG_FUNC pFunc);
void addMessageHandler(LPMSG_FUNC2 pFunc2);

HWND getMMDAgentWnd();

int parseCmd(char* input,char*** pargv);