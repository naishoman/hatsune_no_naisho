﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Collections;

namespace TestEdit
{
    static class Program
    {
        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
//            const string targetTag = "[DynamicsBPList]";            // DYN
//            const string targetTag = "[EpRResidualBPList]";           // BRE
            const string targetTag = "[EpRESlopeBPList]";            // BRI

            int i;

            // DYN 波形テーブル
            const int table_size = 256;
            byte[] dyn_table = new byte[table_size];

            // 適当な波形 山形
            for (i = 0; i < 192; i++)
                dyn_table[i] = (byte)(40+24*i/192);
            for (i = 192; i < 256; i++)
                dyn_table[i] = (byte)(64-32*(i-192)/64);

            // メモリーにファイルを読み込む(手抜き)
            FileStream ifs = new FileStream(args[0], FileMode.Open);
            byte[] buf = new byte[ifs.Length];
            ifs.Read(buf, 0, (int)ifs.Length);
            ifs.Close();

            // 入出力オープン
            MemoryStream mem = new MemoryStream(buf);
            StreamReader istm = new StreamReader(mem, Encoding.GetEncoding(932));
            FileStream ofs = new FileStream(args[0], FileMode.Create);
            StreamWriter ostm = new StreamWriter(ofs, Encoding.GetEncoding(932));

            string line;

            // EventListまで読み飛ばしつつ書き出す
            while ((line = istm.ReadLine()) != null)
            {
                ostm.Write(line + "\n");
                if (line == "[EventList]")
                    break;
            }
            // EventListを読み込む
            // (EventListは、連番だとして手抜き)
            ArrayList evtlist = new ArrayList();
            char[] token = new Char[] { '=' };
            while ((line = istm.ReadLine()) != null)
            {
                ostm.Write(line + "\n");
                string[] evtitem = line.Split(token);
                if ( evtitem[1] == "EOS" )
                    break;
                evtlist.Add(Int32.Parse(evtitem[0]));
            }

            // targetTagまで読み飛ばしつつ書き出す
            // Eventを探しながら波形リストを作成
            // (IDが5ケタになったらどうなるんだろ･･･？)
            bool fTargetExist = false;
            ArrayList wave_list = new ArrayList();
            int evt_idx = 0;
            string evt_header;
            evt_header = "[ID#0000]";
            while ((line = istm.ReadLine()) != null)
            {
                ostm.Write(line + "\n");

                if (line == targetTag)
                {
                    fTargetExist = true;
                    break;
                }

                if (line == evt_header)
                {
                    evt_header = String.Format("[ID#{0,0:0000}]", ++evt_idx);
                    line = istm.ReadLine();
                    ostm.Write(line + "\n");
                    if (line != "Type=Anote")   // ノートイベントか確認
                        continue;
                    line = istm.ReadLine();
                    ostm.Write(line + "\n");
                    string[] length = line.Split(token);
                    if (length[0] != "Length")   // Lengthか確認
                        continue;

                    //波形リストを作成
                    int note_length = Int32.Parse(length[1]);
                    for (i = 0; i < note_length; i++)
                    {
                        int tick = (int)evtlist[evt_idx-1]+i;
                        int value = dyn_table[table_size * i / note_length];
                        wave_list.Add(tick.ToString() + "=" + value.ToString());
                    }
                }
            }

            // targetTagを書き出し
            if (!fTargetExist)
                ostm.Write(targetTag+"\n");
            foreach (string wave_item in wave_list)
                ostm.Write(wave_item + "\n");

            // 次のセクションから書き出す
            bool fNext = false;
            while ((line = istm.ReadLine()) != null)
            {
                if (line.Substring(0, 1) == "[")
                    fNext = true;
                if ( fNext )
                    ostm.Write(line + "\n");
            }

            istm.Close();
            ostm.Close();
            ofs.Close();
            mem.Close();
        }
    }
}