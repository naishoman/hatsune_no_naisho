#include "PluginHelper.h"
#include <tchar.h>

// Unicode�`���̃v���O�C�����ȈՃT�|�[�g����
#define SUPPORT_OLD_MMDAGENT

#define	MESSAGE_DELIMITER "|"

#ifdef SUPPORT_OLD_MMDAGENT
bool isUnicode = false;
#endif

static MSG_HANDLER* pCmdHandlerTree = NULL;
static MSG_HANDLER* pEvtHandlerTree = NULL;
static MSG_HANDLER2* pWMHandlerTree = NULL;
static HWND hMMDAgentWnd = NULL;

extern void initPlugin(HWND hWnd);
extern void termPlugin(HWND hWnd);

HWND getMMDAgentWnd()
{
	return hMMDAgentWnd;
}

static void addMMDHandler(MSG_HANDLER** pMsgHandlerTree,const char* szEvent,LPEVENT_FUNC pFunc)
{
	MSG_HANDLER* pNew;
	if ( *pMsgHandlerTree )
	{
		pNew = *pMsgHandlerTree;
		while ( pNew->pNext )
			pNew = pNew->pNext;
		pNew->pNext = new MSG_HANDLER;
		pNew=pNew->pNext;
	}
	else
	{
		pNew = new MSG_HANDLER;
		*pMsgHandlerTree = pNew;
	}
	pNew->szMessage = strdup(szEvent);
	pNew->pFunc = pFunc;
	pNew->pNext = NULL;

}

void addCommandMessageHandler(const char* szEvent,LPEVENT_FUNC pFunc)
{
	addMMDHandler(&pCmdHandlerTree,szEvent,pFunc);
}

void addEventMessageHandler(const char* szEvent,LPEVENT_FUNC pFunc)
{
	addMMDHandler(&pEvtHandlerTree,szEvent,pFunc);
}

static void addMMDHandler(MSG_HANDLER** pMsgHandlerTree,LPEVENT_FUNC2 pFunc2)
{
	MSG_HANDLER* pNew;
	if ( *pMsgHandlerTree )
	{
		pNew = *pMsgHandlerTree;
		while ( pNew->pNext )
			pNew = pNew->pNext;
		pNew->pNext = new MSG_HANDLER;
		pNew=pNew->pNext;
	}
	else
	{
		pNew = new MSG_HANDLER;
		*pMsgHandlerTree = pNew;
	}
	pNew->szMessage = NULL;
	pNew->pFunc2 = pFunc2;
	pNew->pNext = NULL;

}

void addCommandMessageHandler(LPEVENT_FUNC2 pFunc2)
{
	addMMDHandler(&pCmdHandlerTree,pFunc2);
}

void addEventMessageHandler(LPEVENT_FUNC2 pFunc2)
{
	addMMDHandler(&pEvtHandlerTree,pFunc2);
}

void addMessageHandler(UINT uiMsg,LPMSG_FUNC pFunc)
{
	MSG_HANDLER2* pNew;
	if ( pWMHandlerTree )
	{
		pNew =pWMHandlerTree;
		while ( pNew->pNext )
			pNew = pNew->pNext;
		pNew->pNext = new MSG_HANDLER2;
		pNew=pNew->pNext;
	}
	else
	{
		pNew = new MSG_HANDLER2;
		pWMHandlerTree = pNew;
	}
	pNew->uiMsg = uiMsg;
	pNew->pFunc = pFunc;
	pNew->pNext = NULL;

}

void addMessageHandler(LPMSG_FUNC2 pFunc2)
{
	MSG_HANDLER2* pNew;
	if ( pWMHandlerTree )
	{
		pNew = pWMHandlerTree;
		while ( pNew->pNext )
			pNew = pNew->pNext;
		pNew->pNext = new MSG_HANDLER2;
		pNew=pNew->pNext;
	}
	else
	{
		pNew = new MSG_HANDLER2;
		pWMHandlerTree = pNew;
	}
	pNew->uiMsg = 0;
	pNew->pFunc2 = pFunc2;
	pNew->pNext = NULL;

}

static void freeMessageHandler(MSG_HANDLER* pMsgHandlerTree)
{
	if ( pMsgHandlerTree )
	{
		MSG_HANDLER* pHandler = pMsgHandlerTree;
		while ( pHandler->pNext )
		{
			MSG_HANDLER* pNext = pHandler->pNext;
			delete pHandler;
			pHandler = pNext;
		}
	}

}

static void freeMessageHandler(MSG_HANDLER2* pMsgHandlerTree)
{
	if ( pMsgHandlerTree )
	{
		MSG_HANDLER2* pHandler = pMsgHandlerTree;
		while ( pHandler->pNext )
		{
			MSG_HANDLER2* pNext = pHandler->pNext;
			delete pHandler;
			pHandler = pNext;
		}
	}

}

int parseCmd(char* input,char*** pargv)
{
	int argc = 0;

	int delim_len = strlen(MESSAGE_DELIMITER);
	char* p = input-delim_len;
	for ( ; p ; p=strstr(p+delim_len,MESSAGE_DELIMITER), argc++ );

	char** argv = new char*[argc];

	p = input;
	int i = 0;
	while ( p )
	{
		argv[i++] = p;
		p = strstr(p,MESSAGE_DELIMITER);
		if ( p )
		{
			*p = '\0';
			p += delim_len;
		}
	}
	*pargv = argv;
	return argc;
}

static bool checkHandler(MSG_HANDLER* pMsgHandlerTree,WPARAM wParam,LPARAM lParam)
{
	if ( !pMsgHandlerTree )
		return false;

	char* tmp;

#ifdef SUPPORT_OLD_MMDAGENT
	/* �ȈՕ����R�[�h�`�F�b�N */
	static bool check_charset;
	if ( !check_charset )
	{
		/* �R�}���h�́A���Ԃ�p�������Ȃ̂ť���B�ꕶ������Unicode�A����ȊO����sjis�Ƃ���B*/
		isUnicode = ( strlen((char*)wParam) == 1 );
		check_charset = true;
	}

	/* ���v���O�C���d�l�ł����UTF-16->SJIS�ϊ����� */
	if ( isUnicode )
	{
		int len;

		len = WideCharToMultiByte( CP_ACP, 0, (WCHAR*)lParam, -1, NULL, 0, NULL, NULL );
		tmp = (char*)malloc(len);
		WideCharToMultiByte( CP_ACP, 0, (WCHAR*)lParam, -1, tmp, len, NULL, NULL );

		len = WideCharToMultiByte( CP_ACP, 0, (WCHAR*)wParam, -1, NULL, 0, NULL, NULL );
		char* szCmd = (char*)malloc(len);
		WideCharToMultiByte( CP_ACP, 0, (WCHAR*)wParam, -1, szCmd, len, NULL, NULL );
		wParam = (WPARAM)szCmd;
	}
	else
		tmp = strdup((char*)lParam);
#else
	tmp = strdup((char*)lParam);
#endif

	if ( !tmp )
		return false;

	int argc;
	char** argv = NULL;
	argc = parseCmd(tmp,&argv);

	MSG_HANDLER* pHandler = pMsgHandlerTree;
	while ( pHandler )
	{
		if ( pHandler->szMessage )
		{
			if ( !strcmp(pHandler->szMessage,(char*)wParam) )
				pHandler->pFunc(argc,argv);
		}
		else
			pHandler->pFunc2((char*)wParam,argc,argv);

		pHandler = pHandler->pNext;
	}
	delete[] argv;
	free(tmp);

#ifdef SUPPORT_OLD_MMDAGENT
	if ( isUnicode )
	{
		/* ��n�� */
		free((char*)wParam);
	}
#endif

	return true;
}

bool processCommand(WPARAM wParam,LPARAM lParam)
{
	return checkHandler(pCmdHandlerTree,wParam,lParam);
}

bool processEvent(WPARAM wParam,LPARAM lParam)
{
	return checkHandler(pEvtHandlerTree,wParam,lParam);
}

void postEventMessage(const char* szEvent,const char* szParam)
{
	const char* argv[] = {szParam};
	postEventMessage(szEvent,1,argv);
}

void postEventMessage(const char* szEvent,int argc,const char* argv[])
{
	postMessage(WM_MMDAGENT_EVENT,szEvent,argc,argv);
}

void postCommandMessage(const char* szEvent,const char* szParam)
{
	const char* argv[] = {szParam};
	postCommandMessage(szEvent,1,argv);
}

void postCommandMessage(const char* szEvent,int argc,const char* argv[])
{
	postMessage(WM_MMDAGENT_COMMAND,szEvent,argc,argv);
}

void postMessage(UINT msg,const char* szEvent,int argc,const char* argv[])
{
	int delim_len = strlen(MESSAGE_DELIMITER);
	int len = delim_len * argc;
	for ( int i = 0 ; i < argc ; i++ )
		len += strlen(argv[i]);

	WPARAM wParam;
	LPARAM lParam;

	char* args = (char*)malloc(len);
	*args = '\0';
	for ( int i = 0 ; i < argc ; i++ )
	{
		if ( i )
			strcat(args,MESSAGE_DELIMITER);

		strcat(args,argv[i]);
	}

	wParam = (WPARAM)strdup(szEvent);
	lParam = (LPARAM)args;

#ifdef SUPPORT_OLD_MMDAGENT
	/* ���v���O�C���d�l�ł����SJIS->UTF-16�ϊ����� */
	if ( isUnicode )
	{
		int len;

		len = MultiByteToWideChar(CP_ACP, 0, szEvent, -1, NULL,0);
		WCHAR* wszCmd = new WCHAR[len];
		MultiByteToWideChar(CP_ACP, 0, szEvent, -1, wszCmd, len );
		free((char*)wParam);
		wParam = (WPARAM)wszCmd;

		len = MultiByteToWideChar(CP_ACP, 0, args, -1, NULL,0);
		WCHAR* wszParam = new WCHAR[len];
		MultiByteToWideChar(CP_ACP, 0, args, -1, wszParam, len );
		free(args);
		lParam = (LPARAM)wszParam;
	}
#endif

	::PostMessage(hMMDAgentWnd,msg,wParam,lParam);
}

/* extWindowProc: catch message */
void __stdcall extWindowProc(MMDAgent *m, HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	if  ( pWMHandlerTree )
	{
		MSG_HANDLER2* pHandler = pWMHandlerTree;
		
		while ( pHandler )
		{
			if ( pHandler->uiMsg )
			{
				if ( pHandler->uiMsg == message )
					pHandler->pFunc(wParam,lParam);
			}
			else
				pHandler->pFunc2(message,wParam,lParam);

			pHandler = pHandler->pNext;
		}
	}

	/* case WM_CREATE: */
	/* �ȑO�́AWM_CREATE�Ŏ��s���Ă����A�V�����o�[�W�����ł͌Ăяo�����Ȃ��̂ť�� */
	/* extAppStart�Ɉړ����ׂ��Ƃ͎v�����AHWND�����Ȃ��̂łƂ肠���������� */
	if ( !hMMDAgentWnd )
	{
		hMMDAgentWnd = hWnd;
		initPlugin(hWnd);
	}

	switch ( message )
	{
		/* ������������ ���Ɉړ�
		case WM_CREATE:
			hMMDAgentWnd = hWnd;
			initPlugin(hWnd);
			break;
		*/

		case WM_DESTROY:
			freeMessageHandler(pCmdHandlerTree);
			freeMessageHandler(pEvtHandlerTree);
			freeMessageHandler(pWMHandlerTree);
			termPlugin(hWnd);
			break;

		case WM_MMDAGENT_EVENT:
			processEvent(wParam,lParam);
			break;

		case WM_MMDAGENT_COMMAND:
			processCommand(wParam,lParam);
			break;
	}
}

#define MMDAGNT_TITLE	TEXT("MMDAgent - Toolkit for building voice interaction systems")
#define MMDAGNT_CLASS	TEXT("MMDAgent")
WNDPROC pOrigWndProc = NULL;

typedef struct _MMDAGENT_FIND
{
	DWORD dwProcessId;
	HWND hWnd;
} MMDAGENT_FIND;

// ���C���E�B���h�E�����p
BOOL CALLBACK EnumFindMainWnd(HWND hWnd, LPARAM lParam)
{
	MMDAGENT_FIND* param = (MMDAGENT_FIND*)lParam;

	DWORD dwProcessId = 0;
	GetWindowThreadProcessId(hWnd,&dwProcessId);

	if ( dwProcessId != param->dwProcessId )
		return TRUE;

	TCHAR buf[256];
	GetWindowText(hWnd,buf,255);
	if ( _tcscmp(buf,MMDAGNT_TITLE) )
		return TRUE;

	GetClassName(hWnd,buf,255);
	if ( _tcscmp(buf,MMDAGNT_CLASS) )
		return TRUE;

	param->hWnd = hWnd;
	return FALSE;
}

HWND FindMMDAgent()
{
	MMDAGENT_FIND param;
	param.dwProcessId = GetCurrentProcessId();
	EnumWindows(EnumFindMainWnd,(LPARAM)&param);
	return param.hWnd;
}

LRESULT CALLBACK MyWndProc(HWND hWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	extWindowProc(NULL,hWnd,msg,wp,lp);
	return CallWindowProc(pOrigWndProc, hWnd, msg, wp, lp);
}

/* extProcCommand: process command message */
void __stdcall extProcCommand(MMDAgent *mmdagent, const char *type, const char *args)
{
	if ( !hMMDAgentWnd )
	{
		HWND hWnd = FindMMDAgent();
		// �͂��߂̃R�}���h���������ŏ�������
		extWindowProc(NULL,hWnd,WM_MMDAGENT_COMMAND,(WPARAM)type,(LPARAM)args);
		if ( hMMDAgentWnd )
			pOrigWndProc = (WNDPROC)SetWindowLong( hMMDAgentWnd, GWL_WNDPROC, (LONG)MyWndProc);
	}
}

/* extProcEvent: process event message */
void __stdcall extProcEvent(MMDAgent *mmdagent, const char *type, const char *args)
{
	if ( !hMMDAgentWnd )
	{
		HWND hWnd = FindMMDAgent();
		// �͂��߂̃C�x���g���������ŏ�������
		extWindowProc(NULL,hWnd,WM_MMDAGENT_EVENT,(WPARAM)type,(LPARAM)args);
		if ( hMMDAgentWnd )
			pOrigWndProc = (WNDPROC)SetWindowLong( hMMDAgentWnd, GWL_WNDPROC, (LONG)MyWndProc);
	}
}
