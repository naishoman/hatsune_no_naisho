// Plugin_SAPI.cpp : DLL �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"

#include <mmsystem.h>
#include <objbase.h>
#include <process.h>
#include <mbstring.h>

#include "PluginHelper.h"

#ifdef _MANAGED
#pragma managed(push, off)
#endif

/* ���d�l�̃��b�v�V���N���� */
//#define OLD_LIPSYNC

#define WM_SPEAK						(WM_USER+99)

#define PLUGINAQUESTALK_STARTCOMMAND	"SYNTH_START"
#define PLUGINAQUESTALK_STOPCOMMAND		"SYNTH_STOP"
#define PLUGINAQUESTALK_EVENTSTART		"SYNTH_EVENT_START"
#define PLUGINAQUESTALK_EVENTSTOP		"SYNTH_EVENT_STOP"

typedef unsigned char * (__stdcall *AQUESTALK2_SYNTHE)(const char *koe, int iSpeed, int *pSize, void *phontDat);
typedef void (__stdcall *AQUESTALK2_FREEWAVE)(unsigned char *wav);
AQUESTALK2_SYNTHE AquesTalk2_Synthe = NULL;
AQUESTALK2_FREEWAVE AquesTalk2_FreeWave = NULL;
HMODULE hAquesTalk2Module = NULL;

typedef struct _SYNTH_INFO
{
	char* szSpeaker;
	char* szText;
} SYNTH_INFO;

HINSTANCE hInstance = NULL;
char szIniName[MAX_PATH+1];
char szCurrentPhontPath[MAX_PATH+1] = {0};
void* pCurrentPhont = NULL;

char* makePhonemeSequence(unsigned char* wav,int size)
{
	// �f�[�^�ʒu�Ƃ��v�Z�B�i���낢��蔲���j
	const int div = 20;
	const int start = 44;
	const int tick = 1000 / div;
	int block_size = 8000 * 2 / div; //50ms

	const char* visme_tbl[] = {"n","u","i","e","o","A"};

	// 8 > 6 = strlen(",A,100")
	int max_len = (size/block_size+1)*8;
	char buf[8];

	char* ret = (char*)malloc(max_len);
	*ret = '\0';

	for ( int pos = start ; pos < size ; pos += block_size )
	{
		int data_size = size - pos;
		if ( data_size > block_size )
			data_size = block_size;
		data_size /= sizeof(short);

		short* data = (short*)(wav+pos);
		int abs_total = 0;
		for ( int i = 0 ; i < data_size ; i++ )
		{
			short data_abs = data[i];
			if ( data_abs < 0 )
				data_abs = -data_abs;
			abs_total += data_abs;
		}

		int idx_max = sizeof(visme_tbl)/sizeof(visme_tbl[0]);
		int idx = (int)(abs_total * idx_max * 1.5/ 32768 / data_size);	// 1.5=������
		if ( idx >= idx_max )
			idx = idx_max-1;

		if ( pos != start )
			strcat(ret,",");

#ifdef OLD_LIPSYNC
		sprintf(buf,"%s%d",visme_tbl[idx],tick);
#else
		sprintf(buf,"%s,%d",visme_tbl[idx],tick);
#endif
		strcat(ret,buf);
	}

	return ret;
}

/* synthesis_thread */
void synthesis_thread(void *param)
{
	SYNTH_INFO* info = (SYNTH_INFO*)param;

	postEventMessage(PLUGINAQUESTALK_EVENTSTART,info->szSpeaker);

	char szPhontName[MAX_PATH];
	GetPrivateProfileStringA(info->szSpeaker, "phont", "", szPhontName, MAX_PATH, szIniName);
	int speed = GetPrivateProfileIntA(info->szSpeaker, "speed", 100, szIniName);

	/* phont�ݒ肠�� */
	if ( *szPhontName )
	{
		char szPhontPath[MAX_PATH+1];

		//	MMDAgent::getAppDirName()�Ƃ��Ăт������ǁA�ˑ��֌W�����������Č��Ȃ̂ť��
		strcpy(szPhontPath,szIniName);
		char* szFilePath = (char*)_mbsrchr( (const unsigned char*)szPhontPath, '\\' );
		strcpy( szFilePath+1, szPhontName );

		/* �V����phont */
		if ( strcmp(szCurrentPhontPath,szPhontPath) )
		{
			if ( pCurrentPhont )
			{
				free(pCurrentPhont);
				*szCurrentPhontPath = '\0';
				pCurrentPhont = NULL;
			}


			FILE* fp = fopen(szPhontPath,"rb");
			if ( fp )
			{
				fseek(fp,0,SEEK_END);
				int size = ftell(fp);
				rewind(fp);
				pCurrentPhont = malloc(size);
				if ( pCurrentPhont )
				{
					fread(pCurrentPhont,size,1,fp);
					strcpy(szCurrentPhontPath,szPhontPath);
				}
				fclose(fp);
			}
		}
	}
	else
	{
		if ( pCurrentPhont )
		{
			free(pCurrentPhont);
			*szCurrentPhontPath = '\0';
			pCurrentPhont = NULL;
		}
	}

	int size = 0;
	unsigned char* wav = AquesTalk2_Synthe(info->szText, speed, &size, pCurrentPhont);
	if ( wav )
	{
		char *szLipSymbol = makePhonemeSequence(wav,size);
		const char* args[] = {info->szSpeaker,szLipSymbol};
		postCommandMessage(MMDAGENT_COMMAND_LIPSYNCSTART,2,args);
		free(szLipSymbol);

		PlaySound((LPCWSTR)wav,hInstance,SND_MEMORY);
		AquesTalk2_FreeWave(wav);
	}

	postEventMessage(PLUGINAQUESTALK_EVENTSTOP,info->szSpeaker);

	free(info->szSpeaker);
	free(info->szText);
	delete info;
}

void startSynth(int argc,char *argv[])
{
	/* SYNTH_START command */
	if ( argc == 3 )
	{
		SYNTH_INFO* info = new SYNTH_INFO;
		info->szText = strdup(argv[2]);
		info->szSpeaker = strdup(argv[0]);
		_beginthread(synthesis_thread, 0, info);
	}
}

void stopSynth(int argc,char *argv[])
{
	/* SYNTH_STOP command */
	/* �������Ă��Ӗ��Ȃ������Ȃ̂Ŏ蔲���Ŗ����� */
}

void procSynth(WPARAM wParam, LPARAM lParam)
{
}

void initPlugin(HWND hWnd)
{
	char szFileName[MAX_PATH+1];
	char *szFilePath;

	GetModuleFileNameA(NULL,szFileName,MAX_PATH);
	szFilePath = (char*)_mbsrchr( (const unsigned char*)szFileName, '\\' );
	strcpy( szFilePath , "\\AppData\\AquesTalk2\\phont.ini" );
	strcpy( szIniName, szFileName );

	strcpy( szFilePath , "\\AppData\\AquesTalk2\\AquesTalk2.dll" );
	hAquesTalk2Module = LoadLibraryA(szFileName);
	if ( !hAquesTalk2Module )
		return;

	AquesTalk2_Synthe = (AQUESTALK2_SYNTHE)GetProcAddress(hAquesTalk2Module,"AquesTalk2_Synthe");
	AquesTalk2_FreeWave = (AQUESTALK2_FREEWAVE)GetProcAddress(hAquesTalk2Module,"AquesTalk2_FreeWave");

	if ( !AquesTalk2_Synthe || !AquesTalk2_FreeWave )
		return;

	addCommandMessageHandler(PLUGINAQUESTALK_STARTCOMMAND,startSynth);
	addCommandMessageHandler(PLUGINAQUESTALK_STOPCOMMAND,stopSynth);
	addMessageHandler(WM_COMMAND,procSynth);
}

void termPlugin(HWND hWnd)
{
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			DisableThreadLibraryCalls(hModule);
			hInstance = hModule;
			break;

		case DLL_PROCESS_DETACH:
			if ( hAquesTalk2Module )
				FreeLibrary(hAquesTalk2Module);
			if ( pCurrentPhont )
				free(pCurrentPhont);
			break;
		case DLL_THREAD_DETACH:
		case DLL_THREAD_ATTACH:
			break;
	}
    return TRUE;
}

#ifdef _MANAGED
#pragma managed(pop)
#endif

